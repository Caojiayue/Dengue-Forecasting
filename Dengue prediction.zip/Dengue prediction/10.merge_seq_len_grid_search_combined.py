import pandas as pd
import os


def extract_and_combine_best_grid_results():
    # ================= 配置区 =================
    BEST_CSV = 'params_result/best_models_per_country.csv'
    OUTPUT_CSV = 'params_result/best_grid_search_combined.csv'
    # 假设三个子文件夹与脚本同级。若实际在其它目录，请修改 BASE_DIR
    BASE_DIR = 'params_result'
    # ==========================================

    if not os.path.exists(BEST_CSV):
        raise FileNotFoundError(f"❌ 找不到最佳参数表: {BEST_CSV}")

    print(f"📖 加载最佳参数表: {BEST_CSV}")
    best_df = pd.read_csv(BEST_CSV)

    # 1. 智能识别列名（兼容大小写/前后空格）
    cols = [c.strip() for c in best_df.columns]
    country_col = next((c for c in cols if 'country' in c.lower()), None)
    model_col = next((c for c in cols if 'model' in c.lower()), None)

    if not country_col or not model_col:
        raise ValueError("❌ 无法识别 Country 或 Model 列，请检查 CSV 表头。")

    # 确保参数字段为数值型
    for col in ['num_layers', 'hidden_size', 'batch_size']:
        if col in best_df.columns:
            best_df[col] = pd.to_numeric(best_df[col], errors='coerce')
        else:
            raise KeyError(f"❌ 最佳参数表中缺少关键列: {col}")

    combined_dfs = []
    total_countries = len(best_df)
    print(f"🌍 开始遍历 {total_countries} 个国家...\n")

    for idx, row in best_df.iterrows():
        country = str(row[country_col]).strip()
        model = str(row[model_col]).strip().upper()  # GRU / LSTM / RNN

        nl = row['num_layers']
        hs = row['hidden_size']
        bs = row['batch_size']

        # 动态拼接路径: {BASE_DIR}/{MODEL}_params/{COUNTRY}/all_grid_search_results.csv
        folder_name = f"{model}(params)"
        grid_path = os.path.join(BASE_DIR, folder_name, country, "all_grid_search_results.csv")

        if not os.path.exists(grid_path):
            print(f"⚠️ [{idx + 1}/{total_countries}] {country} | 文件不存在 -> {grid_path}")
            continue

        try:
            grid_df = pd.read_csv(grid_path)
        except Exception as e:
            print(f"❌ [{idx + 1}/{total_countries}] {country} | 读取失败: {e}")
            continue

        # 统一网格数据列类型，避免 字符串 vs 浮点数 比较失效
        for c in ['num_layers', 'hidden_size', 'batch_size']:
            if c in grid_df.columns:
                grid_df[c] = pd.to_numeric(grid_df[c], errors='coerce')
            else:
                print(f"⚠️ {country} 网格表缺少列: {c}")
                grid_df = pd.DataFrame()
                break

        if grid_df.empty:
            continue

        # 精确筛选满足三列参数的所有行
        mask = (grid_df['num_layers'] == nl) & \
               (grid_df['hidden_size'] == hs) & \
               (grid_df['batch_size'] == bs)

        filtered = grid_df[mask].copy()

        if filtered.empty:
            print(f"⚠️ [{idx + 1}/{total_countries}] {country} | 无匹配行 (nl={nl}, hs={hs}, bs={bs})")
            continue

        # 附加溯源信息，便于后续按国家分组
        filtered['Country'] = country
        filtered['Best_Model'] = model
        combined_dfs.append(filtered)

        print(f"✅ [{idx + 1}/{total_countries}] {country} ({model}) | 成功提取 {len(filtered)} 行")

    # ================= 合并与保存 =================
    if not combined_dfs:
        print("\n❌ 未找到任何匹配数据，请检查路径结构或参数列名。")
        return

    final_df = pd.concat(combined_dfs, ignore_index=True)
    final_df.to_csv(OUTPUT_CSV, index=False, encoding='utf-8-sig')

    print(f"\n🎉 处理完成！共合并 {len(final_df)} 条记录。")
    print(f"💾 结果已保存至: {OUTPUT_CSV}")
    print("\n📊 数据预览:")
    print(final_df.head())


if __name__ == "__main__":
    extract_and_combine_best_grid_results()