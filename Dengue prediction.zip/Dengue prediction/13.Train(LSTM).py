import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
import time
import random
import os

def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size):
        super(LSTMModel, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.LSTM = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True
        )
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out, _ = self.LSTM(x)
        last_output = out[:, -1, :]
        y_pred = self.fc(last_output)
        return y_pred

def create_sequences(X, y, seq_len):
    X_seq, y_seq = [], []
    for i in range(seq_len, len(X)):
        X_seq.append(X[i - seq_len: i])
        y_seq.append(y[i])
    return np.array(X_seq), np.array(y_seq)

def load_and_preprocess_data_for_country(data_df, country, base_iv_dir):
    country_data = data_df[data_df['country'] == country].copy()
    if country_data.empty:
        raise ValueError(f"No data found for country: {country}")

    # 修复原路径拼接可能导致的格式问题，可根据实际目录名微调
    iv_file = os.path.join(base_iv_dir, f"Model_Train({country})", "Train-Results-", "Iv.txt")
    if not os.path.exists(iv_file):
        # 兼容原代码中的 "Train-Results-" 目录名
        iv_file_alt = os.path.join(base_iv_dir, f"Model_Train({country})", "Train-Results-", "Iv.txt")
        if not os.path.exists(iv_file_alt):
            raise FileNotFoundError(f"Iv file not found for {country}")
        iv_file = iv_file_alt

    Iv1 = pd.read_csv(iv_file, header=None)
    Iv = Iv1.values.astype(np.float32).flatten()

    Ih_new = country_data['actual_cases'].values.astype(np.float32)
    T = country_data['temperature'].values.astype(np.float32)
    R = country_data['precipitation'].values.astype(np.float32)

    if len(T) != len(Iv):
        raise ValueError(f"Length mismatch for {country}: T={len(T)}, Iv={len(Iv)}")

    scaler_X = MinMaxScaler()
    scaler_y = MinMaxScaler()
    X = np.column_stack([T, R, Iv])
    X_scaled = scaler_X.fit_transform(X)
    Ih_new_scaled = scaler_y.fit_transform(Ih_new.reshape(-1, 1))

    return X_scaled, Ih_new_scaled, Ih_new, scaler_X, scaler_y

def main():
    start_time = time.time()
    set_seed(42)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # ================= 固定参数设置 =================
    FIXED_SEQ_LEN = 3
    FIXED_NUM_LAYERS = 3
    FIXED_HIDDEN_SIZE = 48
    FIXED_BATCH_SIZE = 48
    FIXED_LR = 0.001
    FIXED_EPOCHS = 3000
    # ==============================================

    input_size = 3
    output_size = 1

    data_path = "data.csv"
    base_iv_dir = "Model_Train/Model_Train"
    output_base = "Country_Results"
    os.makedirs(output_base, exist_ok=True)

    data_df = pd.read_csv(data_path)
    countries = ['Honduras']
    print(f"Found {len(countries)} countries: {list(countries)}")

    for idx, country in enumerate(countries, 1):
        print(f"\n{'=' * 60}")
        print(f"Processing country {idx}/{len(countries)}: {country}")
        print('=' * 60)

        try:
            country_output_dir = os.path.join(output_base, country)
            os.makedirs(country_output_dir, exist_ok=True)

            X_scaled, Ih_new_scaled, Ih_new_original, scaler_X, scaler_y = load_and_preprocess_data_for_country(
                data_df, country, base_iv_dir
            )

            # 创建序列
            X_seq, y_seq = create_sequences(X_scaled, Ih_new_scaled, FIXED_SEQ_LEN)
            if len(X_seq) <= 24:
                print(f"⚠️ Not enough data for {country} after sequence creation (len={len(X_seq)}). Skipping.")
                continue

            split_idx = len(X_seq) - 24
            X_train, y_train = X_seq[:split_idx], y_seq[:split_idx]
            X_test, y_test = X_seq[split_idx:], y_seq[split_idx:]

            X_train_dev = torch.tensor(X_train, dtype=torch.float32)
            y_train_dev = torch.tensor(y_train, dtype=torch.float32)
            X_test_dev = torch.tensor(X_test, dtype=torch.float32)
            y_test_dev = torch.tensor(y_test, dtype=torch.float32)

            # 初始化模型
            model = LSTMModel(input_size, FIXED_HIDDEN_SIZE, FIXED_NUM_LAYERS, output_size)
            model.to(device)
            criterion = nn.MSELoss()
            optimizer = optim.Adam(model.parameters(), lr=FIXED_LR)

            # 训练并记录损失
            history = []
            model.train()
            for epoch in range(FIXED_EPOCHS):
                epoch_loss = 0.0
                total_samples = 0
                for i in range(0, len(X_train_dev), FIXED_BATCH_SIZE):
                    end = min(i + FIXED_BATCH_SIZE, len(X_train_dev))
                    X_batch = X_train_dev[i:end].to(device)
                    y_batch = y_train_dev[i:end].to(device)

                    optimizer.zero_grad()
                    y_pred = model(X_batch)
                    loss = criterion(y_pred, y_batch)
                    loss.backward()
                    optimizer.step()

                    epoch_loss += loss.item() * len(y_batch)
                    total_samples += len(y_batch)

                epoch_loss /= total_samples
                history.append(epoch_loss)
                if (epoch + 1) % 100 == 0 or epoch == 0:
                    print(f"  Epoch {epoch+1}/{FIXED_EPOCHS}, Loss: {epoch_loss:.6f}")

            # 1. 保存训练损失历史文件
            loss_path = os.path.join(country_output_dir, 'training_loss_history_LSTM.txt')
            with open(loss_path, 'w') as f:
                f.write("Epoch\tLoss\n")
                for e, l in enumerate(history):
                    f.write(f"{e}\t{l:.6f}\n")

            # 预测
            model.eval()
            with torch.no_grad():
                y_train_pred_scaled = model(X_train_dev.to(device)).cpu().numpy()
                y_test_pred_scaled = model(X_test_dev.to(device)).cpu().numpy()

            y_train_pred = scaler_y.inverse_transform(y_train_pred_scaled)
            y_test_pred = scaler_y.inverse_transform(y_test_pred_scaled)
            y_train_true = scaler_y.inverse_transform(y_train.reshape(-1, 1))
            y_test_true = scaler_y.inverse_transform(y_test.reshape(-1, 1))

            train_mse = mean_squared_error(y_train, y_train_pred_scaled)
            test_mse = mean_squared_error(y_test, y_test_pred_scaled)
            print(f"✅ Train MSE: {train_mse:.6f}, Test MSE: {test_mse:.6f}")

            # 2. 保存模型预测结果
            full_pred = np.concatenate([y_train_pred, y_test_pred], axis=0)
            full_true = np.concatenate([y_train_true, y_test_true], axis=0)
            pred_df = pd.DataFrame({
                'true_Ih_new': full_true.flatten(),
                'pred_Ih_new': full_pred.flatten()
            })
            pred_df.to_csv(os.path.join(country_output_dir, 'predicted_Ih_new_LSTM.csv'), index=False)

            # 3. 保存模型文件
            torch.save({
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scaler_X': scaler_X,
                'scaler_y': scaler_y,
                'fixed_params': {
                    'seq_len': FIXED_SEQ_LEN,
                    'num_layers': FIXED_NUM_LAYERS,
                    'hidden_size': FIXED_HIDDEN_SIZE,
                    'batch_size': FIXED_BATCH_SIZE,
                    'lr': FIXED_LR,
                    'n_epochs': FIXED_EPOCHS
                },
                'train_mse': train_mse,
                'test_mse': test_mse
            }, os.path.join(country_output_dir, 'LSTM_model.pth'))

            print(f"✅ Results saved for {country} in {country_output_dir}")

        except Exception as e:
            print(f"❌ Failed to process {country}: {e}")
            import traceback
            traceback.print_exc()
            continue

    print(f"\n🎉 All countries processed. Results saved in: {output_base}")
    end_time = time.time()
    print(f"⏱️ Total running time: {end_time - start_time:.2f} seconds ({(end_time - start_time)/60:.2f} minutes)")

if __name__ == '__main__':
    main()