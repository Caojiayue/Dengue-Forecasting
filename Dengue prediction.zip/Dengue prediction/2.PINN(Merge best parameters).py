import os
import pandas as pd
import re

# Define the root directory path (update this if your path is different)
root_dir = "Model_Train/Model_Train"

best_results = []

# Iterate through all subdirectories in the root directory
for country_folder in os.listdir(root_dir):
    folder_path = os.path.join(root_dir, country_folder)

    # Check if it is a directory
    if os.path.isdir(folder_path):
        # Construct the path to the target CSV file
        csv_path = os.path.join(folder_path, "Train-Results-", "hyperparameter_mse_results.csv")

        # Check if the file exists
        if os.path.exists(csv_path):
            # Extract country name from folder name (e.g., "Model_Train(Barbados)" -> "Barbados")
            match = re.search(r'\((.*?)\)', country_folder)
            country_name = match.group(1) if match else country_folder

            try:
                # Read the CSV file
                df = pd.read_csv(csv_path)

                # Clean column names just in case there are hidden spaces
                df.columns = df.columns.str.strip()

                # Find the row with the minimum 'total_mse'
                best_row = df.loc[df['total_mse'].idxmin()].copy()

                # Add the country name to this row
                best_row['Country'] = country_name

                # Append to the results list
                best_results.append(best_row)
                print(f"Processed: {country_name}")

            except Exception as e:
                print(f"Error processing {country_folder}: {e}")

# Merge all best results into a single DataFrame
if best_results:
    final_df = pd.DataFrame(best_results)

    # Reorder columns to put 'Country' first
    cols = ['Country'] + [col for col in final_df.columns if col != 'Country']
    final_df = final_df[cols]

    # Define the output path
    output_path = os.path.join(root_dir, "best_hyperparameters_all_countries.csv")

    # Save the merged DataFrame to a new CSV file
    final_df.to_csv(output_path, index=False)

    print(f"\nSuccess! Merged data for {len(final_df)} countries.")
    print(f"Results saved to: {output_path}")
    print("\nPreview of the merged data:")
    print(final_df.to_string(index=False))
else:
    print("No valid data files were found. Please check the root directory path and folder structure.")