import os
import pandas as pd
from pathlib import Path


def merge_country_metrics(base_dir, output_path="merged_country_metrics_no_Iv.csv"):
    base_path = Path(base_dir)
    if not base_path.exists():
        raise FileNotFoundError(f"❌ 目录不存在: {base_dir}")

    all_data = []
    # 按文件夹名排序，保证输出顺序稳定
    for country_folder in sorted(base_path.iterdir()):
        if not country_folder.is_dir():
            continue

        country_name = country_folder.name
        # 🔍 匹配前缀为 params_ 的文件（支持任意后缀）
        target_files = list(country_folder.glob("params_*"))

        if not target_files:
            print(f"⚠️ 跳过 {country_name}：未找到以 'params_' 开头的文件")
            continue

        # 默认取第一个匹配项（通常每个国家仅有一个）
        file_path = target_files[0]

        try:
            df = pd.read_csv(file_path)
            # 清理列名两侧可能存在的空格
            df.columns = df.columns.str.strip()

            required_cols = ['train_mse', 'test_mse', 'train_r2', 'test_r2']
            missing_cols = [col for col in required_cols if col not in df.columns]

            if missing_cols:
                print(f"⚠️ {country_name}: 文件缺少列 {missing_cols}，将填充为 NaN")
                for col in missing_cols:
                    df[col] = float('nan')

            # 提取目标列并插入国家名到首列
            extracted = df[required_cols].copy()
            extracted.insert(0, 'Country', country_name)

            all_data.append(extracted)
            print(f"✅ 已提取: {country_name} → {file_path.name}")

        except Exception as e:
            print(f"❌ 读取 {file_path} 失败: {e}")
            continue

    if not all_data:
        print("❌ 未收集到任何有效数据，程序退出。")
        return None

    # 合并所有国家数据
    merged_df = pd.concat(all_data, ignore_index=True)
    merged_df.to_csv(output_path, index=False, encoding='utf-8-sig')

    print(f"\n🎉 合并成功！共 {len(merged_df)} 行数据。")
    print(f"📁 保存路径: {os.path.abspath(output_path)}")
    print(f"📊 最终列名: {list(merged_df.columns)}")
    return merged_df


if __name__ == "__main__":
    # ⬇️ 请替换为您的实际路径
    BASE_DIR = "Country_Results(no_Iv)"
    merge_country_metrics(BASE_DIR)