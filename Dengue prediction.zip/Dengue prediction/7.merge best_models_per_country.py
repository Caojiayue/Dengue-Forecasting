import pandas as pd
import os


def extract_best_models_per_country(input_csv, output_csv):
    # 1. 读取数据
    if not os.path.exists(input_csv):
        raise FileNotFoundError(f"找不到输入文件: {input_csv}")

    df = pd.read_csv(input_csv)

    # 验证必要列
    required_cols = {'Country', 'test_mse'}
    if not required_cols.issubset(df.columns):
        missing = required_cols - set(df.columns)
        raise ValueError(f"输入文件缺少必要列: {missing}")

    # 2. 剔除 test_mse 为空的行（避免影响最小值查找）
    df_valid = df.dropna(subset=['test_mse'])

    if df_valid.empty:
        print("⚠️ 没有有效的 test_mse 数据，无法提取最优模型。")
        return None

    # 检查是否有国家因全为 NaN 被剔除
    lost_countries = set(df['Country'].unique()) - set(df_valid['Country'].unique())
    if lost_countries:
        print(f"⚠️ 以下国家因 test_mse 全为 NaN 被剔除: {lost_countries}")

    # 3. 按国家分组，获取每个国家 test_mse 最小值的行索引
    best_idx = df_valid.groupby('Country')['test_mse'].idxmin()

    # 4. 提取完整行（自动保留原始所有列及顺序）
    best_models_df = df_valid.loc[best_idx].copy()

    # 5. 按国家名称排序，便于查看
    best_models_df = best_models_df.sort_values('Country').reset_index(drop=True)

    # 6. 保存结果
    best_models_df.to_csv(output_csv, index=False, encoding='utf-8-sig')

    print(f"\n✅ 提取成功！共保留 {len(best_models_df)} 个国家的最优模型记录。")
    print(f"📁 输出路径: {os.path.abspath(output_csv)}")
    print(f"📊 最终列名: {list(best_models_df.columns)}")
    return best_models_df


if __name__ == "__main__":
    # ⬇️ 请替换为您的实际路径
    INPUT_FILE = "params_result/merged_best_params_all_models.csv"
    OUTPUT_FILE = "params_result/best_models_per_country.csv"

    extract_best_models_per_country(INPUT_FILE, OUTPUT_FILE)