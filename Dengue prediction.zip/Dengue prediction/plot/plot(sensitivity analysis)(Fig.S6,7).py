import pandas as pd
import matplotlib.pyplot as plt
import os
import numpy as np


def plot_all_countries_sensitivity_grid():
    # ================= 配置区 =================
    INPUT_CSV = 'params_result/best_grid_search_combined.csv'
    OUTPUT_PATH = 'Figures_submitted/Figure 12_seq_len_sensitivity_grid.pdf'
    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)

    # 子图网格：7行×2列 = 14个国家
    N_ROWS, N_COLS = 2, 7
    FIG_SIZE = (21, 6)  # 宽×高，保证每个子图清晰

    # 绘图样式
    MARKERS = ['o', 's', '^', 'v', 'D', '*', 'p', 'h', 'x', '+', 'd', '|', '_', '.']
    COLORS = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd',
              '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf']
    FONT_SIZE = {'title': 11, 'label': 9, 'tick': 8, 'legend': 8}

    # 是否统一Y轴范围（便于国家间对比，设为False则自适应）
    UNIFY_Y_AXIS = False
    # ==========================================

    if not os.path.exists(INPUT_CSV):
        raise FileNotFoundError(f"❌ 找不到合并数据: {INPUT_CSV}")

    print(f"📖 加载数据: {INPUT_CSV}")
    df = pd.read_csv(INPUT_CSV)

    # 1. 基础校验与清洗
    required_cols = ['Country', 'Best_Model', 'seq_len', 'test_r2']
    for col in required_cols:
        if col not in df.columns:
            raise KeyError(f"❌ 数据缺少必要列: {col}")

    df['seq_len'] = pd.to_numeric(df['seq_len'], errors='coerce')
    df['test_r2'] = pd.to_numeric(df['test_r2'], errors='coerce')
    df = df.dropna(subset=['seq_len', 'test_r2'])

    # 2. 按国家分组并排序
    countries = sorted(df['Country'].unique())
    n_countries = len(countries)
    print(f"🌍 共 {n_countries} 个国家 | 子图网格: {N_ROWS}×{N_COLS}\n")

    if n_countries > N_ROWS * N_COLS:
        print(f"⚠️ 国家数({n_countries}) > 子图数({N_ROWS * N_COLS})，将仅绘制前 {N_ROWS * N_COLS} 个。")
        countries = countries[:N_ROWS * N_COLS]

    # 3. 创建大画布
    fig, axes = plt.subplots(N_ROWS, N_COLS, figsize=FIG_SIZE, sharex=False, sharey=UNIFY_Y_AXIS)
    axes = axes.flatten()  # 展平为1维数组方便索引

    # 可选：计算全局Y轴范围（若开启统一坐标轴）
    if UNIFY_Y_AXIS:
        global_ymin = df['test_r2'].min()
        global_ymax = df['test_r2'].max()
        y_margin = (global_ymax - global_ymin) * 0.1
        global_ylim = (global_ymin - y_margin, global_ymax + y_margin)

    # 4. 遍历绘制每个国家
    for idx, country in enumerate(countries):
        ax = axes[idx]
        country_df = df[df['Country'] == country].copy().sort_values('seq_len')

        if country_df.empty:
            ax.set_visible(False)
            continue

        model = country_df['Best_Model'].iloc[0]
        seq_lens = country_df['seq_len'].values
        test_r2s = country_df['test_r2'].values

        # 样式循环分配
        marker = MARKERS[idx % len(MARKERS)]
        color = COLORS[idx % len(COLORS)]

        # 绘制曲线
        ax.plot(seq_lens, test_r2s,
                marker=marker, markersize=5, linewidth=1.5,
                color=color, label='test_r2', zorder=3)

        # 标题：严格按用户要求包含 Country + Model
        ax.set_title(f'{country}\nModel: {model}', fontsize=FONT_SIZE['title'], pad=8)

        # 坐标轴标签（仅最左列显示Y标签，仅最下行显示X标签）
        if idx % N_COLS == 0:  # 第一列
            ax.set_ylabel('Test r2', fontsize=FONT_SIZE['label'])
        if idx >= N_COLS * (N_ROWS - 1):  # 最后一行
            ax.set_xlabel('Sequence Length', fontsize=FONT_SIZE['label'])

        # 刻度与网格
        ax.tick_params(axis='both', labelsize=FONT_SIZE['tick'])
        ax.grid(True, linestyle='--', alpha=0.3, zorder=1)
        ax.set_axisbelow(True)

        # 统一Y轴范围（若开启）
        if UNIFY_Y_AXIS:
            ax.set_ylim(global_ylim)

        # 隐藏空余子图（若国家数 < 14）
        if idx >= n_countries:
            ax.set_visible(False)

    # 5. 全局标题与图例
    fig.suptitle('Sensitivity of Test r2 to Sequence Length Across Countries',
                 fontsize=16, fontweight='bold', y=0.995)

    # 可选：添加统一图例（若所有国家曲线样式一致可注释掉）
    # from matplotlib.lines import Line2D
    # legend_elements = [Line2D([0], [0], color='gray', label='test_r2')]
    # fig.legend(handles=legend_elements, loc='upper center', bbox_to_anchor=(0.5, -0.01),
    #            ncol=1, fontsize=FONT_SIZE['legend'], frameon=False)

    # 6. 布局优化与保存
    plt.tight_layout(rect=[0, 0.01, 1, 0.99])  # 为suptitle预留顶部空间
    plt.savefig(OUTPUT_PATH, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()

    print(f"✅ 合并图已保存: {OUTPUT_PATH}")
    print(f"📏 图片尺寸: {FIG_SIZE[0]}×{FIG_SIZE[1]} 英寸 | DPI: 300")


if __name__ == "__main__":
    plot_all_countries_sensitivity_grid()