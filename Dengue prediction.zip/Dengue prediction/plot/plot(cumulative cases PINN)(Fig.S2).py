import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
import numpy as np
from sklearn.metrics import r2_score, mean_squared_error

data = pd.read_csv('data.csv')
Ih_sum = pd.read_csv('merged_Ih_sum_all_countries.csv')
selected_countries = [
    'Barbados', 'Bolivia', 'Brazil', 'Colombia', 'Costa Rica',
    'Dominican Republic', 'Ecuador', 'El Salvador', 'Guatemala', 'Honduras', 'Mexico',
    'Paraguay', 'Peru', 'Thailand'
]
data = data[data['country'].isin(selected_countries)]

# 3. 创建画布和子图 (6行2列)
fig, axes = plt.subplots(7, 2, figsize=(20, 28))
axes = axes.flatten()  # 将子图数组展平为一维
start_date = datetime(2014, 1, 1)
# 5. 遍历每个国家
for i, country in enumerate(selected_countries):
    # 获取该国数据
    country_data = data[data['country'] == country].copy()
    country_data_Isum = Ih_sum[Ih_sum['country'] == country].copy()
    # 获取当前子图
    ax = axes[i]
    ax.tick_params(axis='both', labelsize=14)
    dates = [start_date + pd.DateOffset(months=int(day)) for day in country_data['time_points']]

    # 绘制真实新病例数据 (改为散点图)
    scatter = ax.scatter(dates, country_data['actual_cumulative'],
                         color='black', alpha=0.7, label='Reported cumulative cases', s=30)
    # 绘制拟合新病例数据 (折线图)
    line_fit, = ax.plot(dates, country_data_Isum['Ih_sum'],
                        color='#0000FF', linestyle='-', linewidth=2,
                        markersize=4, label='PINN fit')
    # 计算R²和归一化均方误差(NMSE)
    y_true = country_data['actual_cumulative'].values
    y_pred = country_data_Isum['Ih_sum'].values

    # 确保没有NaN值
    mask = ~np.isnan(y_true) & ~np.isnan(y_pred)
    y_true_clean = y_true[mask]
    y_pred_clean = y_pred[mask]

    if len(y_true_clean) > 0 and len(y_pred_clean) > 0:
        # 计算R²
        r2 = r2_score(y_true_clean, y_pred_clean)

        # 计算归一化均方误差(NMSE)
        # NMSE = MSE / (y_true的方差)
        mse = mean_squared_error(y_true_clean, y_pred_clean)
        y_var = np.var(y_true_clean)
        if y_var > 0:
            nmse = mse / y_var
        else:
            nmse = np.nan

        # 在右上角显示指标
        metrics_text = f'R² = {r2:.5f}\nMSE = {nmse:.5f}'
        ax.text(0.98, 0.95, metrics_text,
                transform=ax.transAxes,
                fontsize=10,
                verticalalignment='top',
                horizontalalignment='right',
                bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.8,
                          edgecolor='gray'))
    else:
        # 如果没有有效数据，显示NA
        ax.text(0.98, 0.95, 'R² = NA\nMSE = NA',
                transform=ax.transAxes,
                fontsize=10,
                verticalalignment='top',
                horizontalalignment='right',
                bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.8,
                          edgecolor='gray'))

    # 设置x轴刻度
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
    ax.set_ylim(bottom=0)
    ax.set_xlim(left=datetime(2014, 1, 1), right=dates[-1])
    ax.xaxis.set_major_locator(mdates.YearLocator(base=1))
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
    ax.ticklabel_format(style='scientific', axis='y', scilimits=(0, 0))
    ax.tick_params(axis='x', labelsize=14,rotation=30)
    ax.set_ylabel('Cumulative Cases', fontsize=14)
    ax.tick_params(axis='y', labelsize=14, colors='#0000FE')

    # === 关键：国家名作为图例的标题 ===
    lines = [scatter, line_fit]
    ax.legend(
        lines,
        [l.get_label() for l in lines],
        title=country,  # ← 国家名在这里！
        title_fontsize=14,
        loc='upper left',
        fontsize=14,
        framealpha=0.9,
        fancybox=True
    )

# 隐藏多余子图（虽然15个刚好填满）
# plt.subplots_adjust(wspace=0.01)  # 横向间距，0.05是非常小的间距
# plt.tight_layout(pad=1.5, h_pad=2.5,w_pad=0.1)
plt.tight_layout()
plt.savefig("Figures_submitted/Figure S1_Ih_sum_PINN.pdf", dpi=300)
plt.show()