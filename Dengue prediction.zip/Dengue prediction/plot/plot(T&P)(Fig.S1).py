import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

# 假设你的数据已经加载到 DataFrame 中
df = pd.read_csv('data.csv')
# 创建月度时间序列
date_range = pd.date_range(
    start='2014-01',
    end='2025-04',
    freq='MS'  # MS = Month Start (e.g., 2014-01-01, 2014-02-01, ...)
)

# 按国家分组
countries = df['country'].unique()
num_countries = len(countries)

# 设置子图布局（例如 5 行 4 列，适应 17 个国家）
n_cols = 2
n_rows = 7

# 创建大图
fig, axes = plt.subplots(n_rows, n_cols, figsize=(20,28))
axes = axes.flatten()  # 将 axes 转为一维数组便于索引

# 遍历每个国家
for idx, country in enumerate(countries):
    ax1 = axes[idx]
    country_data = df[df['country'] == country].sort_values('date')

    # 绘制温度（左侧 y 轴）
    line_fit1, = ax1.plot(date_range, country_data['temperature'], color='tab:red', label='Temperature')
    ax1.set_ylabel('Temperature (°C)',fontsize= 20, color='tab:red')
    ax1.tick_params(axis='y',labelsize=20, labelcolor='tab:red')
    #ax1.set_title(country)
   # ax1.grid(True, alpha=0.3)
    # 创建第二个 y 轴绘制降雨量
    ax2 = ax1.twinx()
    line_fit2, = ax2.plot(date_range, country_data['precipitation'], color='tab:blue', label='Precipitation')
    ax2.set_ylabel('Precipitation (mm)',fontsize= 20, color='tab:blue')
    ax2.tick_params(axis='y',labelsize=20, labelcolor='tab:blue')
    # --- 关键：设置 x 轴只显示年份 ---
    ax1.xaxis.set_major_locator(mdates.YearLocator())  # 每年一个刻度
    ax1.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))  # 只显示年份（如 2014）
    ax1.tick_params(axis='x',labelsize=20, rotation=30)  # 不旋转，水平显示
    ax1.set_ylim(bottom=10)
    ax1.set_xlim(left=date_range[0], right=date_range[-1])
    ax2.set_ylim(bottom=0)
    ax2.set_xlim(left=date_range[0], right=date_range[-1])
    lines = [ line_fit1, line_fit2]
    ax1.legend(
        lines,
        [l.get_label() for l in lines],
        loc='upper left',
        fontsize = 18,
        framealpha=0.9,
        fancybox=True
    )
    # ------------------------------
# 隐藏多余的子图（如果子图数量大于国家数）
for j in range(idx + 1, len(axes)):
    fig.delaxes(axes[j])

# 调整布局
fig.tight_layout()
# 添加图例说明（可放在图外）
plt.savefig('Figures_submitted/Fig s1_T&R.pdf',dpi=300)
