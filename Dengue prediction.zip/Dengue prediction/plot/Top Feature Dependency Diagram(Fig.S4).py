import matplotlib.pyplot as plt
import numpy as np
import os
import shap

# 国家列表
selected_countries = [
        'Barbados', 'Bolivia', 'Brazil', 'Colombia', 'Costa Rica',
        'Dominican Republic', 'Ecuador', 'El Salvador', 'Guatemala', 'Honduras', 'Mexico',
        'Paraguay', 'Peru', 'Thailand'
    ]

country_results_dir = 'shap_results'
output_path = 'Figures_submitted'
os.makedirs(output_path, exist_ok=True)

# 创建 5x3 大图
fig, axes = plt.subplots(7, 2, figsize=(15, 30))
axes_flat = axes.flatten()

for idx, country in enumerate(selected_countries):
    shap_file = os.path.join(country_results_dir, country,  "shap_analysis.npz")

    if not os.path.exists(shap_file):
        print(f"⚠️ SHAP file missing for {country}. Skipping.")
        axes_flat[idx].axis('off')
        continue

    try:
        data = np.load(shap_file, allow_pickle=True)
        shap_values_2d = data['shap_values_2d']  # (n_samples, n_features)
        X_explain_2d = data['X_explain_2d']      # (n_samples, n_features)
        feature_names = data['feature_names'].tolist()

        # 1. 计算每个特征的平均 |SHAP| 值 → 找出最重要特征
        mean_abs_shap = np.mean(np.abs(shap_values_2d), axis=0)  # (n_features,)
        top_feature_idx = np.argmax(mean_abs_shap)
        top_feature_name = feature_names[top_feature_idx]

        # 2. 绘制该特征的依赖图
        ax = axes_flat[idx]
        shap.dependence_plot(
            top_feature_idx,
            shap_values_2d,
            X_explain_2d,
            feature_names=feature_names,
            show=False,
            ax=ax, interaction_index=None)

        ax.set_title(f"{country}\n(Top: {top_feature_name})", fontsize=14, fontweight='bold', wrap=True)
        ax.set_xlabel(top_feature_name, fontsize=14)
        ax.set_ylabel(f"SHAP value for\n{top_feature_name}", fontsize=14)

        # 可选：调整 y 轴范围以避免极端值影响布局
        # y_min, y_max = ax.get_ylim()
        # ax.set_ylim(max(-0.5, y_min), min(0.5, y_max))

    except Exception as e:
        print(f"❌ Error plotting for {country}: {e}")
        axes_flat[idx].axis('off')

# 隐藏多余子图
for j in range(len(selected_countries), len(axes_flat)):
    axes_flat[j].axis('off')

# 调整布局并保存
plt.tight_layout(pad=3.0)
plt.savefig(os.path.join(output_path, "Figuer6_SHAP_TopFeature_Dependence_14Countries.pdf"), dpi=300, bbox_inches='tight')
plt.close(fig)

print("✅ Top-feature dependence plots saved to:", output_path)