import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime

data = pd.read_csv('merged_training_loss.csv')
data1 = pd.read_csv('params_result/best_models_per_country.csv')
selected_countries = [
    'Barbados', 'Bolivia', 'Brazil', 'Colombia', 'Costa Rica',
    'Dominican Republic', 'Ecuador', 'El Salvador', 'Guatemala', 'Honduras', 'Mexico',
    'Paraguay', 'Peru', 'Thailand']

fig, axes = plt.subplots(7, 2, figsize=(20, 28))
axes = axes.flatten()

for i, country in enumerate(selected_countries):
    ax = axes[i]
    loss_data = data[data['country'] == country].copy()
    model_series = data1[data1['Country'] == country]['model']
    if not model_series.empty:
        model_name = model_series.iloc[0]
    else:
        model_name = 'Unknown'

    ax.plot(loss_data['Epoch'], loss_data['Loss'],
            color='blue', linestyle='-', linewidth=2,
            label=f'{model_name} training loss')

    ax.set_ylim()
    ax.set_xlim()
    ax.tick_params(axis='x', labelsize=14)
    ax.tick_params(axis='y', labelsize=14)
    ax.set_ylabel('MSE Loss', fontsize=14)

    ax.legend(
        title=f"{country}",
        title_fontsize=14,
        loc='upper left',
        fontsize=14,
        framealpha=0.9,
        fancybox=True
    )

# ✅ 关键修改：为最后一行（第5行，索引12,13,14）添加横坐标标签
for j in range(12, 14):
    axes[j].set_xlabel('Epoch', fontsize=14)

plt.tight_layout()
plt.savefig(r"Figures_submitted\Fig. S4_Loss.pdf", dpi=300)
# plt.show()