import matplotlib.pyplot as plt
import numpy as np
import os
import shap

# 国家列表
selected_countries = [
        'Barbados', 'Bolivia', 'Brazil', 'Colombia', 'Costa Rica',
        'Dominican Republic', 'Ecuador', 'El Salvador', 'Guatemala', 'Honduras', 'Mexico',
        'Paraguay', 'Peru', 'Thailand'
    ]

country_results_dir = 'shap_results'
output_path = 'Figures_submitted'  # 保存路径
os.makedirs(output_path, exist_ok=True)

# 创建大画布：5行3列，尺寸 14 x 22
fig_beeswarm, axes_beeswarm = plt.subplots(7, 2, figsize=(15, 30))
fig_bar, axes_bar = plt.subplots(7, 2, figsize=(15, 30))

# 扁平化 axes 以便循环
axes_beeswarm_flat = axes_beeswarm.flatten()
axes_bar_flat = axes_bar.flatten()

for idx, country in enumerate(selected_countries):
    shap_file = os.path.join(country_results_dir, country,  "shap_analysis.npz")

    if not os.path.exists(shap_file):
        print(f"⚠️ SHAP file missing for {country}. Skipping.")
        # 关闭子图
        axes_beeswarm_flat[idx].axis('off')
        axes_bar_flat[idx].axis('off')
        continue

    try:
        data = np.load(shap_file, allow_pickle=True)
        shap_values_2d = data['shap_values_2d']  # (n_samples, 15)
        X_explain_2d = data['X_explain_2d']  # (n_samples, 15)
        feature_names = data['feature_names'].tolist()

        # --- 蜂窝图 (beeswarm) ---
        plt.sca(axes_beeswarm_flat[idx])  # 设置当前子图为绘图目标
        shap.summary_plot(
            shap_values_2d,
            X_explain_2d,
            feature_names=feature_names,
            show=False,
            plot_size=None  # 避免内部调整大小
        )
        axes_beeswarm_flat[idx].set_title(country, fontsize=14, fontweight='bold')
        axes_beeswarm_flat[idx].set_xlabel('')

        # --- 特征重要性 (bar) ---
        plt.sca(axes_bar_flat[idx])
        shap.summary_plot(
            shap_values_2d,
            X_explain_2d,
            feature_names=feature_names,
            plot_type="bar",
            show=False,
            plot_size=None
        )
        axes_bar_flat[idx].set_title(country, fontsize=14, fontweight='bold')
        axes_bar_flat[idx].set_xlabel('')

    except Exception as e:
        print(f"❌ Error plotting {country}: {e}")
        axes_beeswarm_flat[idx].axis('off')
        axes_bar_flat[idx].axis('off')

# 隐藏未使用的子图（理论上15个刚好填满，但保险起见）
for j in range(len(selected_countries), len(axes_beeswarm_flat)):
    axes_beeswarm_flat[j].axis('off')
    axes_bar_flat[j].axis('off')

# 调整布局并保存蜂窝图
plt.figure(fig_beeswarm.number)
plt.tight_layout(pad=3.0)
#fig_beeswarm.suptitle("SHAP Beeswarm Plots for 15 Countries", fontsize=18, y=0.98)
#plt.savefig(os.path.join(output_path, "Figure4_SHAP_Beeswarm_14Countries.svg"), dpi=300, bbox_inches='tight')
plt.savefig(os.path.join(output_path, "Figure4_SHAP_Beeswarm_14Countries.pdf"), dpi=300, bbox_inches='tight')
plt.close(fig_beeswarm)

# 调整布局并保存特征重要性图
plt.figure(fig_bar.number)
plt.tight_layout(pad=3.0)
#plt.savefig(os.path.join(output_path, "Figure5_SHAP_Feature_Importance_14Countries.svg"), dpi=300, bbox_inches='tight')
plt.savefig(os.path.join(output_path, "Figure5_SHAP_Feature_Importance_14Countries.pdf"), dpi=300, bbox_inches='tight')
plt.close(fig_bar)

print("✅ SHAP plots saved to:", output_path)