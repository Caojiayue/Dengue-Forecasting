import matplotlib.pyplot as plt
import numpy as np
import os
import shap

# 国家列表
selected_countries = [
        'Barbados', 'Bolivia', 'Brazil', 'Colombia', 'Costa Rica',
        'Dominican Republic', 'Ecuador', 'El Salvador', 'Guatemala', 'Honduras', 'Mexico',
        'Paraguay', 'Peru', 'Thailand'
    ]

country_results_dir = 'shap_results'
output_path = 'Figures_submitted'
os.makedirs(output_path, exist_ok=True)

# 创建 5x3 大图
fig, axes = plt.subplots(7, 2, figsize=(15, 30))
axes_flat = axes.flatten()

for idx, country in enumerate(selected_countries):
    shap_file = os.path.join(country_results_dir, country,  "shap_analysis.npz")

    if not os.path.exists(shap_file):
        print(f"⚠️ SHAP file missing for {country}. Skipping.")
        axes_flat[idx].axis('off')
        continue

    try:
        data = np.load(shap_file, allow_pickle=True)
        shap_values_2d = data['shap_values_2d']  # (n_samples, n_features)
        X_explain_2d = data['X_explain_2d']      # (n_samples, n_features)
        feature_names = data['feature_names'].tolist()

        # 1. 计算平均 |SHAP| 值
        mean_abs_shap = np.mean(np.abs(shap_values_2d), axis=0)

        # 2. 获取排名第二的特征索引
        # 方法：对 mean_abs_shap 排序，取倒数第2个的原始索引
        sorted_indices = np.argsort(mean_abs_shap)[::-1]  # 从大到小排序的索引
        if len(sorted_indices) < 2:
            print(f"⚠️ Less than 2 features for {country}. Skipping.")
            axes_flat[idx].axis('off')
            continue
        second_top_idx = sorted_indices[1]  # 第二重要的索引
        second_top_name = feature_names[second_top_idx]

        # 3. 绘制依赖图
        ax = axes_flat[idx]
        shap.dependence_plot(
            second_top_idx,
            shap_values_2d,
            X_explain_2d,
            feature_names=feature_names,
            show=False,
            ax=ax,interaction_index=None)
        ax.set_title(f"{country}\n(2nd: {second_top_name})", fontsize=14, fontweight='bold', wrap=True)
        ax.set_xlabel(second_top_name, fontsize=14)
        ax.set_ylabel(f"SHAP value for\n{second_top_name}", fontsize=14)

    except Exception as e:
        print(f"❌ Error plotting 2nd top feature for {country}: {e}")
        axes_flat[idx].axis('off')

# 隐藏多余子图
for j in range(len(selected_countries), len(axes_flat)):
    axes_flat[j].axis('off')

# 调整布局并保存
plt.tight_layout(pad=3.0)

#plt.savefig(os.path.join(output_path, "Figure7_SHAP_SecondFeature_Dependence_15Countries.svg"), dpi=300, bbox_inches='tight')
plt.savefig(os.path.join(output_path, "Figuer7_SHAP_SecondFeature_Dependence_14Countries.pdf"), dpi=300, bbox_inches='tight')
plt.close(fig)

