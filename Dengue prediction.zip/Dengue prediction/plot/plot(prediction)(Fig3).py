import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
import os

# 1. 加载基础数据
data = pd.read_csv("data.csv")
data2 = pd.read_csv('params_result/best_models_per_country.csv')

# 自动适配列名大小写
country_col = 'Country' if 'Country' in data2.columns else 'country'
model_col = 'model' if 'model' in data2.columns else 'Model'

selected_countries = [
    'Barbados', 'Bolivia', 'Brazil', 'Colombia', 'Costa Rica',
    'Dominican Republic', 'Ecuador', 'El Salvador', 'Guatemala', 'Honduras', 'Mexico',
    'Paraguay', 'Peru', 'Thailand'
]

fig, axes = plt.subplots(7, 2, figsize=(20, 28))
axes = axes.flatten()
start_date = datetime(2014, 1, 1)

# 配色定义
COLOR_10 = '#54BAE8'  # 淡蓝色
COLOR_20 = '#9579E8' # 淡紫色

for i, country in enumerate(selected_countries):
    ax = axes[i]
    country_data = data[data['country'] == country].copy()

    if country_data.empty:
        ax.set_visible(False)
        continue

    country_params = data2[data2[country_col] == country]
    if country_params.empty:
        ax.set_visible(False)
        continue

    model_name = str(country_params[model_col].iloc[0])
    seq_len = int(country_params['seq_len'].iloc[0])

    # 生成时间轴
    dates = [start_date + pd.DateOffset(months=int(day)) for day in country_data['time_points']]

    # 实际发病数散点
    scatter = ax.scatter(dates, country_data['actual_cases'],
                         color='black', alpha=0.7, label='Reported new cases', s=20)

    # ================= 加载主预测曲线 =================
    # 1. 带 Iv 的预测文件
    pred_iv_path = os.path.join("Country_Results", country, f"predicted_Ih_new_{model_name}.csv")
    y_pred_iv = []
    if os.path.exists(pred_iv_path):
        pred_iv_df = pd.read_csv(pred_iv_path)
        col_iv = 'pred_Ih_new' if 'pred_Ih_new' in pred_iv_df.columns else pred_iv_df.columns[1]
        y_pred_iv = pred_iv_df[col_iv].values

    # 2. 不带 Iv 的预测文件
    pred_no_iv_path = os.path.join("Country_Results(no_Iv)", country, f"predicted_Ih_new_{model_name}_no_Iv.csv")
    y_pred_no_iv = []
    if os.path.exists(pred_no_iv_path):
        pred_no_iv_df = pd.read_csv(pred_no_iv_path)
        col_no_iv = 'pred_Ih_new' if 'pred_Ih_new' in pred_no_iv_df.columns else pred_no_iv_df.columns[1]
        y_pred_no_iv = pred_no_iv_df[col_no_iv].values

    # 严格对齐预测数据的 x/y 长度
    dates_for_pred = dates[seq_len:]

    line_fit, line_fit2 = None, None
    if len(y_pred_iv) >= len(dates_for_pred):
        line_fit, = ax.plot(dates_for_pred, y_pred_iv[:len(dates_for_pred)],
                            color='red', linestyle='-', linewidth=2,
                            label=f'{model_name} fit(T&R&Iv)')
    else:
        print(f"⚠️ {country}: 带Iv预测数据长度不足或缺失，跳过该曲线。")

    if len(y_pred_no_iv) >= len(dates_for_pred):
        line_fit2, = ax.plot(dates_for_pred, y_pred_no_iv[:len(dates_for_pred)],
                             color='green', linestyle='-', linewidth=2,
                             label=f'{model_name} fit(T&R)')
    else:
        print(f"⚠️ {country}: 不带Iv预测数据长度不足或缺失，跳过该曲线。")

    # ================= 新增：加载并绘制不确定性区间（从倒数第24点开始对齐） =================
    unc_path = os.path.join("Country_Results", country, "iv_uncertainty_combined.csv")
    unc_10_handle, unc_20_handle = None, None

    if os.path.exists(unc_path):
        unc_df = pd.read_csv(unc_path)

        # 提取不确定性边界列（兼容不同列名写法）
        col_plus_10 = next((c for c in unc_df.columns if 'Predicted_Iv_+10%' in c or 'Iv_+10%' in c), None)
        col_minus_10 = next((c for c in unc_df.columns if 'Predicted_Iv_-10%' in c or 'Iv_-10%' in c), None)
        col_plus_20 = next((c for c in unc_df.columns if 'Predicted_Iv_+20%' in c or 'Iv_+20%' in c), None)
        col_minus_20 = next((c for c in unc_df.columns if 'Predicted_Iv_-20%' in c or 'Iv_-20%' in c), None)

        if all([col_plus_10, col_minus_10, col_plus_20, col_minus_20]):
            # 🔴 修改点：从倒数第24个点开始截取（测试集起点）
            n_test = 24
            if len(unc_df) >= n_test:
                y_plus_10 = unc_df[col_plus_10].values[-n_test:]
                y_minus_10 = unc_df[col_minus_10].values[-n_test:]
                y_plus_20 = unc_df[col_plus_20].values[-n_test:]
                y_minus_20 = unc_df[col_minus_20].values[-n_test:]

                # 🔴 修改点：不确定性区间的时间轴也取 dates 的最后24个点
                dates_unc = dates[-n_test:]

                # ±10% 阴影 (淡蓝色)
                unc_10_handle = ax.fill_between(dates_unc, y_minus_10, y_plus_10,
                                                color=COLOR_10, alpha=0.45, zorder=1,
                                                label='Prediction-std-(10%)')
                # ±20% 阴影 (淡紫色)
                unc_20_handle = ax.fill_between(dates_unc, y_minus_20, y_plus_20,
                                                color=COLOR_20, alpha=0.45, zorder=0,
                                                label='Prediction-std-(20%)')
    # ============================================================

    # 动态计算分割线位置
    split_date = dates[-24] if len(dates) > 24 else dates[0]
    ax.axvline(x=split_date, color='b', linestyle='--', lw=2, alpha=0.7, label='Train/Test Split')

    # 坐标轴格式化
    ax.set_xlim(left=datetime(2014, 1, 1), right=dates[-1])
    ax.xaxis.set_major_locator(mdates.YearLocator(base=1))
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))

    if i < 12:
        ax.tick_params(axis='x', labelbottom=False)
    else:
        ax.tick_params(axis='x', labelsize=14, rotation=30)

    ax.tick_params(axis='y', labelsize=14)
    ax.ticklabel_format(style='scientific', axis='y', scilimits=(0, 0))
    ax.set_ylabel('New cases prediction', fontsize=14)

    # 安全构建图例（自动过滤未成功绘制的元素）
    legend_handles = [h for h in [scatter, line_fit, line_fit2, unc_10_handle, unc_20_handle] if h is not None]
    ax.legend(
        legend_handles, [l.get_label() for l in legend_handles],
        title=country, title_fontsize=14,
        loc='upper left', fontsize=13,
        framealpha=0.9, fancybox=True
    )

# 布局与保存
plt.tight_layout()
plt.subplots_adjust(bottom=0.05)
os.makedirs("Figures_submitted", exist_ok=True)
plt.savefig("Figures_submitted/Figure 3_newcases prediction.pdf", dpi=300)
plt.show()