import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import numpy as np
from datetime import datetime
from PIL import Image
import io
from matplotlib.patches import Patch
from sklearn.metrics import r2_score, mean_squared_error

data = pd.read_csv('data.csv')
Inew = pd.read_csv('merged_Ih_new_all_countries.csv')
Iv = pd.read_csv('merged_Iv_all_countries.csv')
selected_countries = [
    'Barbados', 'Bolivia', 'Brazil', 'Colombia', 'Costa Rica',
    'Dominican Republic', 'Ecuador', 'El Salvador', 'Guatemala', 'Honduras', 'Mexico',
    'Paraguay', 'Peru', 'Thailand'
]

fig, axes = plt.subplots(7, 2, figsize=(20, 28))
axes = axes.flatten()
start_date = datetime(2014, 1, 1)

# 厄尔尼诺事件时间范围和对齐年份
el_nino_periods = [
    (datetime(2014, 3, 1), datetime(2016, 5, 31), datetime(2016, 1, 1)),
    (datetime(2018, 9, 1), datetime(2019, 5, 31), datetime(2019, 1, 1)),
    (datetime(2023, 3, 1), datetime(2024, 5, 31), datetime(2023, 1, 1))
]

el_nino_colors = ['red', 'blue', 'green']
el_nino_labels = ['2014-2016 El Niño', '2018-2019 El Niño', '2023-2024 El Niño']

for i, country in enumerate(selected_countries):
    ax = axes[i]
    country_data = data[data['country'] == country].copy()
    country_data_Inew = Inew[Inew['country'] == country].copy()
    country_data_Iv = Iv[Iv['country'] == country].copy()
    if country_data.empty:
        ax.set_visible(False)
        continue

    dates = [start_date + pd.DateOffset(months=int(day)) for day in country_data['time_points']]

    # 绘制厄尔尼诺事件背景（所有子图均保留）
    for j, (start_date_el_nino, end_date_el_nino, align_date) in enumerate(el_nino_periods):
        ax.axvspan(start_date_el_nino, end_date_el_nino, alpha=0.1,
                   color=el_nino_colors[j])

    scatter = ax.scatter(dates, country_data['actual_cases'],
                         color='black', alpha=0.7, label='Reported new cases', s=30)
    line_fit, = ax.plot(dates[1:], country_data_Inew['Ih_new'][1:],
                        color='#0000FF', linestyle='-', linewidth=2,
                        label='PINN fit')
    ax2 = ax.twinx()
    line_iv, = ax2.plot(dates, country_data_Iv['Iv'],
                        color='#FF00FF', linestyle='--', linewidth=2,
                        label='Iv')

    # 计算R²和NMSE
    y_true = country_data['actual_cases'].values[1:]
    y_pred = country_data_Inew['Ih_new'].values[1:]
    mask = ~np.isnan(y_true) & ~np.isnan(y_pred)
    y_true_clean = y_true[mask]
    y_pred_clean = y_pred[mask]

    if len(y_true_clean) > 0 and len(y_pred_clean) > 0:
        r2 = r2_score(y_true_clean, y_pred_clean)
        mse = mean_squared_error(y_true_clean, y_pred_clean)
        y_var = np.var(y_true_clean)
        nmse = mse / y_var if y_var > 0 else np.nan
        metrics_text = f'R² = {r2:.5f}\nMSE = {nmse:.5f}'
    else:
        metrics_text = 'R² = NA\nMSE = NA'

    ax.text(0.98, 0.95, metrics_text,
            transform=ax.transAxes, fontsize=10,
            verticalalignment='top', horizontalalignment='right',
            bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.8, edgecolor='gray'))

    # 统一设置x轴定位器与格式化器（保持所有子图时间轴严格对齐）
    ax.xaxis.set_major_locator(mdates.YearLocator(base=1))
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
    ax.set_xlim(left=datetime(2014, 1, 1), right=dates[-1])
    ax.ticklabel_format(style='scientific', axis='y', scilimits=(0, 0))
    ax.set_ylim(bottom=0)

    # 🔴 仅在最下方两张图 (索引 12, 13) 显示年份标签
    if i < 12:
        ax.tick_params(axis='x', labelbottom=False)
    else:
        ax.tick_params(axis='x', labelsize=14, rotation=30)

    ax.set_ylabel('New Cases', fontsize=14)
    ax.tick_params(axis='y', labelsize=14, colors='#0000FE')
    ax2.set_ylabel('Iv', fontsize=14)
    ax2.ticklabel_format(style='scientific', axis='y', scilimits=(0, 0))
    ax2.tick_params(axis='y', labelsize=14, colors='#FF00FF')
    ax2.set_ylim(bottom=0)

    # 数据图例（左上角）
    lines = [scatter, line_fit, line_iv]
    ax.legend(
        lines, [l.get_label() for l in lines],
        title=country, title_fontsize=14,
        loc='upper left', fontsize=14, framealpha=0.9, fancybox=True
    )

    # 🔵 仅在最上方两张图 (索引 0, 1) 显示 El Niño 标签
    if i < 2:
        ymax = ax.get_ylim()[1]
        for j, (start_date_el_nino, end_date_el_nino, align_date) in enumerate(el_nino_periods):
            x_pos = mdates.date2num(align_date)
            ax.text(x_pos, ymax * 1.02, el_nino_labels[j],
                    fontsize=12, ha='center', va='bottom',
                    color=el_nino_colors[j], fontweight='bold',
                    transform=ax.transData, clip_on=False)

# 调整布局并保存
plt.tight_layout()
# 防止顶部文字被 tight_layout 压缩裁剪
plt.subplots_adjust(top=0.94)

#plt.savefig("Figures_submitted/Figure 2_newcase and IV.svg", dpi=300)
plt.savefig("Figures_submitted/Figure 2_newcase and IV.pdf", dpi=300)
plt.show()