import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from itertools import product
import time
import random
import os


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


class GRUModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size):
        super(GRUModel, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.GRU = nn.GRU(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True
        )
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out, _ = self.GRU(x)
        last_output = out[:, -1, :]
        y_pred = self.fc(last_output)
        return y_pred


def create_sequences(X, y, seq_len):
    X_seq, y_seq = [], []
    for i in range(seq_len, len(X)):
        X_seq.append(X[i - seq_len: i])
        y_seq.append(y[i])
    return np.array(X_seq), np.array(y_seq)


def load_and_preprocess_data_for_country(data_df, country, base_iv_dir):
    country_data = data_df[data_df['country'] == country].copy()
    if country_data.empty:
        raise ValueError(f"No data found for country: {country}")

    iv_file = os.path.join(base_iv_dir, f"Model_Train({country})", "Train-Results-","Iv.txt")
    if not os.path.exists(iv_file):
        raise FileNotFoundError(f"Iv file not found for {country}: {iv_file}")

    Iv1 = pd.read_csv(iv_file, header=None)
    Iv = Iv1.values.astype(np.float32).flatten()

    Ih_new = country_data['actual_cases'].values.astype(np.float32)
    T = country_data['temperature'].values.astype(np.float32)
    R = country_data['precipitation'].values.astype(np.float32)

    if len(T) != len(Iv):
        raise ValueError(f"Length mismatch for {country}: T={len(T)}, Iv={len(Iv)}")

    scaler_X = MinMaxScaler()
    scaler_y = MinMaxScaler()
    X = np.column_stack([T, R, Iv])
    X_scaled = scaler_X.fit_transform(X)
    Ih_new_scaled = scaler_y.fit_transform(Ih_new.reshape(-1, 1))

    return X_scaled, Ih_new_scaled, Ih_new, scaler_X, scaler_y

def train_and_evaluate(model, X_train, y_train, X_test, y_test,
                       lr, n_epochs, batch_size, device):
    model.to(device)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    X_train_dev = X_train.to(device)
    y_train_dev = y_train.to(device)

    model.train()
    for epoch in range(n_epochs):
        for i in range(0, len(X_train_dev), batch_size):
            end = min(i + batch_size, len(X_train_dev))
            X_batch = X_train_dev[i:end]
            y_batch = y_train_dev[i:end]
            optimizer.zero_grad()
            y_pred = model(X_batch)
            loss = criterion(y_pred, y_batch)
            loss.backward()
            optimizer.step()

    model.eval()
    with torch.no_grad():
        X_test_dev = X_test.to(device)
        y_test_pred_scaled = model(X_test_dev).cpu().numpy()
        y_test_true = y_test.cpu().numpy().reshape(-1, 1)
        test_mse = mean_squared_error(y_test_true, y_test_pred_scaled)
        test_r2 = r2_score(y_test_true, y_test_pred_scaled)
        test_mae = mean_absolute_error(y_test_true, y_test_pred_scaled)  # 🔽 新增

        y_train_pred_scaled = model(X_train_dev).cpu().numpy()
        y_train_true = y_train.cpu().numpy().reshape(-1, 1)
        train_mse = mean_squared_error(y_train_true, y_train_pred_scaled)
        train_r2 = r2_score(y_train_true, y_train_pred_scaled)
        train_mae = mean_absolute_error(y_train_true, y_train_pred_scaled)  # 🔽 新增

    return train_mse, train_r2, train_mae, test_mse, test_r2, test_mae


def main():
    start_time = time.time()
    set_seed(42)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    FIXED_LR = 0.001
    FIXED_EPOCHS = 3000
    input_size = 3
    output_size = 1

    data_path = "data.csv"
    base_iv_dir = "Model_Train"
    output_base = "GRU(params)"

    os.makedirs(output_base, exist_ok=True)

    data_df = pd.read_csv(data_path)
    countries = data_df['country'].unique()
    print(f"Found {len(countries)} countries: {list(countries)}")

    param_grid = {
        'seq_len': [1, 2, 3, 4, 5, 6],
        'num_layers': [2, 3, 4, 5],
        'hidden_size': [16, 32, 48, 64],
        'batch_size': [16, 32, 48, 64]
    }

    param_keys = list(param_grid.keys())
    total_comb = 1
    for v in param_grid.values():
        total_comb *= len(v)
    print(f"every country: {total_comb}")

    total_countries = len(countries)
    for idx, country in enumerate(countries, 1):
        print(f"\n{'=' * 60}")
        print(f"Processing country {idx}/{total_countries}: {country}")
        print('=' * 60)

        try:
            country_output_dir = os.path.join(output_base, country)
            os.makedirs(country_output_dir, exist_ok=True)

            X_scaled, Ih_new_scaled, Ih_new_original, scaler_X, scaler_y = load_and_preprocess_data_for_country(
                data_df, country, base_iv_dir
            )

            best_mse = float('inf')
            best_train_mse = float('inf')
            best_train_mae = float('inf')
            best_test_mae = None
            best_test_r2 = None
            best_train_r2 = None
            best_params = None
            count = 0

            all_results = []

            for params in product(*[param_grid[k] for k in param_keys]):
                seq_len, num_layers, hidden_size, batch_size = params
                count += 1
                print(
                    f"  [{count}/{total_comb}] seq_len={seq_len}, layers={num_layers}, hidden={hidden_size}, batch={batch_size}")

                set_seed(42)
                X_seq, y_seq = create_sequences(X_scaled, Ih_new_scaled, seq_len)
                if len(X_seq) <= 24:
                    continue

                split_idx = len(X_seq) - 24
                X_train, y_train = X_seq[:split_idx], y_seq[:split_idx]
                X_test, y_test = X_seq[split_idx:], y_seq[split_idx:]

                X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
                y_train_tensor = torch.tensor(y_train, dtype=torch.float32)
                X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
                y_test_tensor = torch.tensor(y_test, dtype=torch.float32)

                try:
                    model = GRUModel(input_size, hidden_size, num_layers, output_size)
                    train_mse, train_r2, train_mae, test_mse, test_r2, test_mae = train_and_evaluate(
                        model, X_train_tensor, y_train_tensor, X_test_tensor, y_test_tensor,
                        FIXED_LR, FIXED_EPOCHS, batch_size, device
                    )
                    all_results.append({
                        'seq_len': seq_len, 'num_layers': num_layers,
                        'hidden_size': hidden_size, 'batch_size': batch_size,
                        'lr': FIXED_LR, 'n_epochs': FIXED_EPOCHS,
                        'train_mse': train_mse, 'train_r2': train_r2, 'train_mae': train_mae,
                        'test_mse': test_mse, 'test_r2': test_r2, 'test_mae': test_mae
                    })

                    if test_mse < best_mse:
                        best_mse = test_mse
                        best_test_r2 = test_r2
                        best_test_mae = test_mae
                        best_train_mse = train_mse
                        best_train_r2 = train_r2
                        best_train_mae = train_mae
                        best_params = {
                            'seq_len': seq_len, 'num_layers': num_layers, 'hidden_size': hidden_size,
                            'batch_size': batch_size, 'lr': FIXED_LR, 'n_epochs': FIXED_EPOCHS
                        }
                except Exception as e:
                    print(f"    → Error during training: {e}")
                    continue

            if all_results:
                pd.DataFrame(all_results).to_csv(
                    os.path.join(country_output_dir, 'all_grid_search_results.csv'),
                    index=False, encoding='utf-8-sig'
                )
                print(f"📊 All {len(all_results)} combinations saved to all_grid_search_results.csv")

            if best_params is None:
                print(f"❌ No valid model for {country}. Skipping.")
                continue


            print(f"✅ Best Test MSE: {best_mse:.6f} | Test R²: {best_test_r2:.6f} | Test MAE: {best_test_mae:.6f}")
            print(f"✅ Best Train MSE: {best_train_mse:.6f} | Train R²: {best_train_r2:.6f} | Train MAE: {best_train_mae:.6f}")
            print(f"✅ Best params: {best_params}")

            params_df = pd.DataFrame([best_params])
            params_df['train_mse'] = best_train_mse
            params_df['train_r2'] = best_train_r2
            params_df['train_mae'] = best_train_mae
            params_df['test_mse'] = best_mse
            params_df['test_r2'] = best_test_r2
            params_df['test_mae'] = best_test_mae
            params_df.to_csv(os.path.join(country_output_dir, 'best_params_GRU.csv'), index=False, encoding='utf-8-sig')

        except Exception as e:
            print(f"❌ Failed to process {country}: {e}")
            import traceback
            traceback.print_exc()
            continue

    end_time = time.time()
    total_time = end_time - start_time
    print(f"\n⏱️ : {total_time:.2f} s({total_time / 60:.2f} minutes)")


if __name__ == '__main__':
    main()