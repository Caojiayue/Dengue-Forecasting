import os
import pandas as pd

# === 配置 ===
root_dir = 'Country_Results'  # ←← 替换为你的实际数据根目录
best_model_file = 'params_result/best_models_per_country.csv'  # 上一步生成的各国最优模型文件

# === 读取最优模型信息 ===
best_df = pd.read_csv(best_model_file)
predicted_dfs = []

# === 遍历每个国家的最优模型，读取对应预测文件（.txt）===
for _, row in best_df.iterrows():
    country = row['Country']
    model = row['model']

    # 构建 .txt 预测文件路径
    pred_file = os.path.join(root_dir, country, f'training_loss_history_{model}.txt')

    if not os.path.isfile(pred_file):
        print(f"⚠️ 警告：未找到 {country} 的预测文件：{pred_file}")
        continue

    try:
        # 读取 TXT 文件（假设为制表符 \t 分隔，有 header）
        # 如果是空格分隔，可改用 sep='\s+'；如果是逗号，则 sep=','（但那就不是标准txt了）
        df_pred = pd.read_csv(pred_file, sep='\t')  # ←← 关键修改：指定分隔符

        # 验证列是否存在
        if not {'Epoch', 'Loss'}.issubset(df_pred.columns):
            print(f"❌ 错误：{pred_file} 缺少 'Epoch' 或 'Loss' 列！实际列: {list(df_pred.columns)}")
            continue

        # 添加国家和模型信息
        df_pred['country'] = country
        df_pred['model'] = model

        # 重排列为指定顺序
        df_pred = df_pred[['country', 'model', 'Epoch', 'Loss']]

        predicted_dfs.append(df_pred)

    except Exception as e:
        print(f"❌ 读取失败: {pred_file}, 错误: {e}")

# === 合并所有预测数据 ===
if predicted_dfs:
    merged_pred = pd.concat(predicted_dfs, ignore_index=True)
    merged_pred.to_csv('merged_training_loss.csv', index=False)
    print(f"\n✅ 成功合并 {len(predicted_dfs)} 个国家的最优模型预测结果！")
    print(f"📊 总行数: {len(merged_pred)}")
    print(f"💾 已保存至: merged_training_loss.csv")
else:
    print("❌ 未成功读取任何预测文件！")

# === 可选：按国家查看前几行 ===
if predicted_dfs:
    print("\n🔍 预览（每个国家前2行）：")
    for country in merged_pred['country'].unique():
        subset = merged_pred[merged_pred['country'] == country].head(2)
        print(f"\n{country}:")
        print(subset)