

import os
import pandas as pd
import glob


def merge_ih_new_files(base_dir, output_path="merged_Iv_all_countries.csv"):
    all_data = []

    for folder_name in os.listdir(base_dir):
        if not folder_name.startswith("Model_Train("):
            continue

        # 提取国家名: Model_Train(China) -> China
        country = folder_name.replace("Model_Train(", "").rstrip(")")
        folder_path = os.path.join(base_dir, folder_name)

        # 匹配 Train-Results* 目录下的 Ih_new.txt
        ih_files = glob.glob(os.path.join(folder_path, "Train-Results*", "Iv.txt"))
        if not ih_files:
            print(f"⚠️ 跳过 {country}：未找到 Iv.txt")
            continue

        try:
            # 自动适配空格/制表符分隔，无表头
            df = pd.read_csv(ih_files[0], header=None, sep="\s+")
            df.columns = ["Iv"]

            # 添加 Country 与 Month 列
            df["Country"] = country
            df["Month"] = range(len(df))  # 补0后，索引自动从 0 开始顺延

            # 按需调整：若严格只需要 Country 和 Month 两列，取消下一行注释并注释掉包含 Ih_new 的行
            # all_data.append(df[["Country", "Month"]])
            all_data.append(df[["Country", "Month", "Iv"]])

        except Exception as e:
            print(f"❌ 读取 {country} 的 Ih_new.txt 失败: {e}")
            continue

    if not all_data:
        print("未找到任何有效数据，程序退出。")
        return None

    # 合并所有国家数据并保存
    merged_df = pd.concat(all_data, ignore_index=True)
    merged_df.to_csv(output_path, index=False, encoding="utf-8-sig")

    print(f"\n✅ 合并成功！共 {len(merged_df)} 行数据")
    print(f"📁 已保存至: {os.path.abspath(output_path)}")
    return merged_df


if __name__ == "__main__":
    # ⬇️ 请根据实际路径修改
    BASE_DIR = "Model_Train\Model_Train"
    merge_ih_new_files(BASE_DIR)