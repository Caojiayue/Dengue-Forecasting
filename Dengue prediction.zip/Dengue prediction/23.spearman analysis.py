import pandas as pd
import scipy.stats as stats
import numpy as np

df = pd.read_csv('data.csv', encoding='utf-8')

def categorize_p(p):
    if pd.isna(p):
        return "NaN"
    if p < 0.01:
        return "<0.01"
    elif p < 0.05:
        return "<0.05"  # 实际代表 0.01 ≤ p < 0.05
    else:
        return ">0.05"


# 3️⃣ 计算Spearman相关系数（保留6位小数）
def calc_spearman(x, y, min_samples=5):
    clean = pd.DataFrame({'x': x, 'y': y}).dropna()
    if len(clean) < min_samples:
        return np.nan, np.nan
    rho, p = stats.spearmanr(clean['x'], clean['y'])
    return round(float(rho), 6), float(p)  # p保留原始值用于分类


# 4️⃣ 按国家分组生成目标表格
def generate_correlation_table(df, target='actual_cases', min_samples=5):
    results = []
    for country, group in df.groupby('country'):
        t_cor, t_p = calc_spearman(group['temperature'], group[target], min_samples)
        p_cor, p_p = calc_spearman(group['precipitation'], group[target], min_samples)

        results.append({
            'country': country,
            'T(cor)': t_cor,
            'T(p-value)': categorize_p(t_p),
            'P(cor)': p_cor,
            'P(p_value)': categorize_p(p_p)  # 严格按你要求的列名（下划线）
        })
    return pd.DataFrame(results)


# 5️⃣ 执行分析
result_table = generate_correlation_table(df)

# 6️⃣ 打印结果（相关系数6位小数，P值已分类）
print("📊 Spearman相关性分析结果（P值按阈值分类）：")
print("=" * 60)
with pd.option_context('display.float_format', '{:.6f}'.format):
    print(result_table.to_string(index=False))

# 7️⃣ 导出CSV（可选，兼容Excel）
result_table.to_csv('correlation_p_categorized.csv', index=False, encoding='utf-8-sig')
# print("\n💾 已保存至 correlation_p_categorized.csv")