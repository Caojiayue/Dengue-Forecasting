import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
# 🔽 新增：导入 mean_absolute_error
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import time
import random
import os


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size):
        super(LSTMModel, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.LSTM = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True
        )
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out, _ = self.LSTM(x)
        last_output = out[:, -1, :]
        y_pred = self.fc(last_output)
        return y_pred


def create_sequences(X, y, seq_len):
    X_seq, y_seq = [], []
    for i in range(seq_len, len(X)):
        X_seq.append(X[i - seq_len: i])
        y_seq.append(y[i])
    return np.array(X_seq), np.array(y_seq)


def load_and_preprocess_data_for_country(data_df, country):
    country_data = data_df[data_df['country'] == country].copy()
    if country_data.empty:
        raise ValueError(f"No data found for country: {country}")

    Ih_new = country_data['actual_cases'].values.astype(np.float32)
    T = country_data['temperature'].values.astype(np.float32)
    R = country_data['precipitation'].values.astype(np.float32)

    scaler_X = MinMaxScaler()
    scaler_y = MinMaxScaler()
    X = np.column_stack([T, R])
    X_scaled = scaler_X.fit_transform(X)
    Ih_new_scaled = scaler_y.fit_transform(Ih_new.reshape(-1, 1))

    return X_scaled, Ih_new_scaled, Ih_new, scaler_X, scaler_y


def plot_results(t_star, Ih_new_true, pred_padded, train_mse, test_mse, save_path="LSTM_best.png"):
    font = 24
    fig, ax = plt.subplots(figsize=(13, 6.5))
    split_idx = len(t_star) - 24
    ax.axvline(x=t_star[split_idx], color='b', linestyle='--', lw=2, alpha=0.7, label='Train/Test Split')

    ax.plot(t_star, Ih_new_true, 'k--', marker='o', lw=2, markersize=5, label='True Ih_new')
    ax.plot(t_star, pred_padded, 'r-', lw=2, label='Predicted Ih_new')

    ax.text(0.02, 0.95, f'Train MSE: {train_mse:.6f}\nTest MSE: {test_mse:.6f}',
            transform=ax.transAxes, fontsize=16,
            verticalalignment='top',
            bbox=dict(boxstyle='round,pad=0.3', facecolor='lightyellow', alpha=0.8))

    ax.legend(fontsize=22)
    ax.tick_params(axis='both', labelsize=24)
    ax.ticklabel_format(axis='y', style='sci', scilimits=(3, 3))
    ax.grid(True)
    ax.set_xlabel('months', fontsize=font)
    ax.set_ylabel('Ih_new', fontsize=font)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300)
    plt.close()


def plot_training_loss(history, save_path="LSTM_mse_best.png"):
    plt.figure(figsize=(10, 4))
    plt.plot(history, 'b-', linewidth=1.5)
    plt.title('LSTM Training Loss (MSE) - Best Parameters', fontsize=16)
    plt.xlabel('Epoch', fontsize=14)
    plt.ylabel('Loss', fontsize=14)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300)
    plt.close()


def save_loss_history(history, filename='training_loss_history_LSTM.txt'):
    with open(filename, 'w') as f:
        f.write("Epoch\tLoss\n")
        for epoch, loss in enumerate(history):
            f.write(f"{epoch}\t{loss:.6f}\n")


def main():
    start_time = time.time()
    set_seed(42)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    input_size = 2
    output_size = 1

    data_path = "data.csv"
    params_csv_path = "params_result/best_models_per_country.csv"
    output_base = "Country_Results(no_Iv)"

    os.makedirs(output_base, exist_ok=True)

    data_df = pd.read_csv(data_path)
    #countries = data_df['country'].unique()
    countries = ['Honduras']
    print(f"📊 Found {len(countries)} countries in data: {list(countries)}")

    if not os.path.exists(params_csv_path):
        raise FileNotFoundError(f"❌ 参数文件不存在: {params_csv_path}")

    params_df = pd.read_csv(params_csv_path)
    if 'model' in params_df.columns:
        LSTM_params_df = params_df[params_df['model'] == 'LSTM'].copy()
    else:
        LSTM_params_df = params_df.copy()

    fixed_params_map = {}
    for _, row in LSTM_params_df.iterrows():
        c = row['Country']
        fixed_params_map[c] = {
            'seq_len': int(row['seq_len']),
            'num_layers': int(row['num_layers']),
            'hidden_size': int(row['hidden_size']),
            'batch_size': int(row['batch_size']),
            'lr': float(row['lr']),
            'n_epochs': int(row['n_epochs'])
        }
    print(f"📦 已加载 {len(fixed_params_map)} 个国家的固定 LSTM 参数。")

    total_countries = len(countries)
    for idx, country in enumerate(countries, 1):
        print(f"\n{'=' * 60}")
        print(f"Processing country {idx}/{total_countries}: {country}")
        print('=' * 60)

        if country not in fixed_params_map:
            print(f"⚠️ Skipping {country}: 未在参数文件中找到对应 LSTM 配置。")
            continue

        bp = fixed_params_map[country]
        print(f"🔧 使用固定参数: {bp}")

        try:
            country_output_dir = os.path.join(output_base, country)
            os.makedirs(country_output_dir, exist_ok=True)

            X_scaled, Ih_new_scaled, Ih_new_original, scaler_X, scaler_y = load_and_preprocess_data_for_country(
                data_df, country
            )

            X_seq, y_seq = create_sequences(X_scaled, Ih_new_scaled, bp['seq_len'])
            if len(X_seq) <= 24:
                print(f"⚠️ Not enough data for {country} after sequencing. Skipping.")
                continue

            split_idx = len(X_seq) - 24
            X_train, y_train = X_seq[:split_idx], y_seq[:split_idx]
            X_test, y_test = X_seq[split_idx:], y_seq[split_idx:]

            X_train_dev = torch.tensor(X_train, dtype=torch.float32).to(device)
            y_train_dev = torch.tensor(y_train, dtype=torch.float32).to(device)
            X_test_dev = torch.tensor(X_test, dtype=torch.float32).to(device)
            y_test_dev = torch.tensor(y_test, dtype=torch.float32).to(device)

            model = LSTMModel(input_size, bp['hidden_size'], bp['num_layers'], output_size).to(device)
            criterion = nn.MSELoss()
            optimizer = optim.Adam(model.parameters(), lr=bp['lr'])

            history = []
            for epoch in range(bp['n_epochs']):
                model.train()
                epoch_loss = 0.0
                total_samples = 0
                for i in range(0, len(X_train_dev), bp['batch_size']):
                    end = min(i + bp['batch_size'], len(X_train_dev))
                    X_batch = X_train_dev[i:end]
                    y_batch = y_train_dev[i:end]
                    optimizer.zero_grad()
                    y_pred = model(X_batch)
                    loss = criterion(y_pred, y_batch)
                    loss.backward()
                    optimizer.step()
                    epoch_loss += loss.item() * len(y_batch)
                    total_samples += len(y_batch)
                epoch_loss /= total_samples
                history.append(epoch_loss)

            save_loss_history(history, os.path.join(country_output_dir, 'training_loss_history_LSTM.txt'))

            model.eval()
            with torch.no_grad():
                y_train_pred_scaled = model(X_train_dev).cpu().numpy()
                y_test_pred_scaled = model(X_test_dev).cpu().numpy()

            y_train_pred = scaler_y.inverse_transform(y_train_pred_scaled)
            y_test_pred = scaler_y.inverse_transform(y_test_pred_scaled)
            y_train_true = scaler_y.inverse_transform(y_train.reshape(-1, 1))
            y_test_true = scaler_y.inverse_transform(y_test.reshape(-1, 1))

            train_mse = mean_squared_error(y_train, y_train_pred_scaled.flatten())
            test_mse = mean_squared_error(y_test, y_test_pred_scaled.flatten())

            train_r2 = r2_score(y_train.flatten(), y_train_pred_scaled.flatten())
            test_r2 = r2_score(y_test.flatten(), y_test_pred_scaled.flatten())

            # 🔽 新增：计算训练集与测试集的 MAE
            train_mae = mean_absolute_error(y_train.flatten(), y_train_pred_scaled.flatten())
            test_mae = mean_absolute_error(y_test.flatten(), y_test_pred_scaled.flatten())

            # 🔽 新增：将 MAE 保存至 CSV
            params_df_out = pd.DataFrame([bp])
            params_df_out['train_mse'] = train_mse
            params_df_out['test_mse'] = test_mse
            params_df_out['train_r2'] = train_r2
            params_df_out['test_r2'] = test_r2
            params_df_out['train_mae'] = train_mae
            params_df_out['test_mae'] = test_mae
            params_df_out.to_csv(os.path.join(country_output_dir, 'params_LSTM.csv'), index=False)

            full_pred = np.concatenate([y_train_pred, y_test_pred], axis=0)
            pred_df = pd.DataFrame({
                'true_Ih_new': np.concatenate([y_train_true, y_test_true], axis=0).flatten(),
                'pred_Ih_new': full_pred.flatten()
            })
            pred_df.to_csv(os.path.join(country_output_dir, 'predicted_Ih_new_LSTM_no_Iv.csv'), index=False)

            torch.save({
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scaler_X': scaler_X,
                'scaler_y': scaler_y,
                'best_params': bp,
                'train_mse': train_mse, 'test_mse': test_mse,
                'train_r2': train_r2, 'test_r2': test_r2,
                'train_mae': train_mae, 'test_mae': test_mae  # 🔽 新增：MAE 存入 checkpoint
            }, os.path.join(country_output_dir, 'LSTM_model.pth'))

            t_star = np.arange(len(Ih_new_original), dtype=np.float32)
            Ih_new_pred_padded = np.concatenate([
                np.full((bp['seq_len'], 1), np.nan),
                full_pred
            ], axis=0)

            plot_results(
                t_star, Ih_new_original, Ih_new_pred_padded,
                train_mse, test_mse,
                os.path.join(country_output_dir, 'LSTM.png')
            )
            plot_training_loss(
                history,
                os.path.join(country_output_dir, 'LSTM_mse.png')
            )

            print(f"✅ Results saved for {country} in {country_output_dir}")
            # 🔽 新增：打印 MAE 结果
            print(f"📊 Train R²: {train_r2:.4f} | Test R²: {test_r2:.4f}")
            print(f"📊 Train MAE: {train_mae:.4f} | Test MAE: {test_mae:.4f}")

        except Exception as e:
            print(f"❌ Failed to process {country}: {e}")
            import traceback
            traceback.print_exc()
            continue

    print(f"\n🎉 All countries processed. Results saved in: {output_base}")
    end_time = time.time()
    total_time = end_time - start_time
    print(f"\n⏱️ 总运行时间: {total_time:.2f} 秒 ({total_time / 60:.2f} 分钟)")


if __name__ == '__main__':
    main()