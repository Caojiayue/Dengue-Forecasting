import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import shap
import os
from sklearn.preprocessing import MinMaxScaler


# ================= 模型定义 =================
class RNNModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size):
        super().__init__()
        self.RNN = nn.RNN(input_size=input_size, hidden_size=hidden_size, num_layers=num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out, _ = self.RNN(x)
        return self.fc(out[:, -1, :])


class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size):
        super().__init__()
        self.LSTM = nn.LSTM(input_size=input_size, hidden_size=hidden_size, num_layers=num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out, _ = self.LSTM(x)
        return self.fc(out[:, -1, :])


class GRUModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size):
        super().__init__()
        self.GRU = nn.GRU(input_size=input_size, hidden_size=hidden_size, num_layers=num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out, _ = self.GRU(x)
        return self.fc(out[:, -1, :])


def create_sequences(X, y, seq_len):
    X_seq, y_seq = [], []
    for i in range(seq_len, len(X)):
        X_seq.append(X[i - seq_len: i])
        y_seq.append(y[i])
    return np.array(X_seq), np.array(y_seq)


def load_and_preprocess_data_for_country(data_df, country, base_iv_dir):
    country_data = data_df[data_df['country'] == country].copy()
    if country_data.empty:
        raise ValueError(f"No data found for country: {country}")

    iv_file = os.path.join(base_iv_dir, f"Model_Train({country})", "Train-Results-","Iv.txt")
    Iv = pd.read_csv(iv_file, header=None).values.astype(np.float32).flatten()
    Ih_new = country_data['actual_cases'].values.astype(np.float32)
    T = country_data['temperature'].values.astype(np.float32)
    R = country_data['precipitation'].values.astype(np.float32)

    if len(T) != len(Iv):
        raise ValueError(f"Length mismatch for {country}: T={len(T)}, Iv={len(Iv)}")

    scaler_X, scaler_y = MinMaxScaler(), MinMaxScaler()
    X = np.column_stack([T, R, Iv])  # 特征维度固定为 3
    X_scaled = scaler_X.fit_transform(X)
    Ih_new_scaled = scaler_y.fit_transform(Ih_new.reshape(-1, 1))
    return X_scaled, Ih_new_scaled, Ih_new, scaler_X, scaler_y


# ================= 主逻辑 =================
if __name__ == "__main__":
    # 路径设置
    base_iv_dir = "Model_Train/Model_Train"
    country_results_dir = "Country_Results"
    best_model_csv = "params_result/best_models_per_country.csv"
    data_csv = "data.csv"

    # 加载配置
    best_model_df = pd.read_csv(best_model_csv)
    # 统一列名大小写，防止 KeyError
    best_model_df.columns = best_model_df.columns.str.strip().str.lower()
    data_df = pd.read_csv(data_csv)

    selected_countries = [
        'Barbados', 'Bolivia', 'Brazil', 'Colombia', 'Costa Rica',
        'Dominican Republic', 'Ecuador', 'El Salvador', 'Guatemala', 'Honduras', 'Mexico',
        'Paraguay', 'Peru', 'Thailand'
    ]

    model_class_map = {'rnn': RNNModel, 'lstm': LSTMModel, 'gru': GRUModel}

    for country in selected_countries:
        print(f"\n{'=' * 40}\nProcessing country: {country}\n{'=' * 40}")

        # 1. 🔍 动态读取该国家的最佳模型参数
        country_row = best_model_df[best_model_df['country'] == country]
        if country_row.empty:
            print(f"⚠️ Warning: {country} not found in {best_model_csv}. Skipping.")
            continue

        try:
            row = country_row.iloc[0]
            model_name = str(row['model']).upper()
            seq_len = int(row['seq_len'])
            hidden_size = int(row['hidden_size'])
            num_layers = int(row['num_layers'])
            input_size = 3  # T, R, Iv 固定为 3 个特征
            output_size = 1
            print(f"📦 Params loaded: {model_name} | seq_len={seq_len}, hidden={hidden_size}, layers={num_layers}")
        except KeyError as e:
            print(f"❌ Missing column in CSV: {e}. Skipping {country}.")
            continue

        if model_name.lower() not in model_class_map:
            print(f"❌ Unknown model type: {model_name}. Skipping.")
            continue

        # 2. 加载数据
        try:
            # 修复原代码解压数量不匹配的问题（函数返回5个值）
            X_scaled, y_scaled, Ih_new, scaler_X, scaler_y = load_and_preprocess_data_for_country(
                data_df, country, base_iv_dir
            )
        except Exception as e:
            print(f"❌ Data loading failed: {e}")
            continue

        # 3. 构建序列
        X_seq, y_seq = create_sequences(X_scaled, y_scaled, seq_len)
        if len(X_seq) <= 24:
            print(f"⚠️ Not enough sequence data for {country}. Skipping.")
            continue

        split_idx = len(X_seq) - 24
        X_train, X_test = X_seq[:split_idx], X_seq[split_idx:]

        X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
        X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
        X_explain_tensor = torch.cat([X_train_tensor, X_test_tensor], dim=0)
        background = X_train_tensor[:min(100, len(X_train_tensor))]

        # 4. 🔧 使用动态参数初始化并加载模型
        model_class = model_class_map[model_name.lower()]
        model = model_class(input_size=input_size, hidden_size=hidden_size,
                            num_layers=num_layers, output_size=output_size)

        # 修正模型路径逻辑（假设结构为 Country_Results/{Country}/best_{Model}_model.pth）
        model_path = os.path.join(country_results_dir, country, f"{model_name}_model.pth")
        if not os.path.exists(model_path):
            print(f"❌ Model file not found: {model_path}. Skipping.")
            continue

        checkpoint = torch.load(model_path, map_location='cpu', weights_only=False)
        model.load_state_dict(checkpoint['model_state_dict'])
        model.eval()

        # 5. 📊 SHAP 分析
        try:
            explainer = shap.GradientExplainer(model, background)
            shap_values_raw = explainer.shap_values(X_explain_tensor)

            # 统一处理 SHAP 输出格式
            shap_values_3d = np.array(shap_values_raw[0]) if isinstance(shap_values_raw, list) else np.array(
                shap_values_raw)
            shap_values_2d = shap_values_3d.reshape(shap_values_3d.shape[0], -1)
            X_explain_2d = X_explain_tensor.numpy().reshape(X_explain_tensor.shape[0], -1)

            # 动态生成特征名（适配当前 seq_len）
            feature_names = []
            for lag in range(seq_len):
                lag_label = seq_len - lag
                feature_names.extend([f'$T(t-{lag_label})$', f'$P(t-{lag_label})$', f'$I_v(t-{lag_label})$'])

            # 6. 保存结果
            save_dir = os.path.join( "shap_results",country)
            os.makedirs(save_dir, exist_ok=True)
            save_path = os.path.join(save_dir, "shap_analysis.npz")

            np.savez_compressed(
                save_path,
                shap_values_2d=shap_values_2d,
                shap_values_3d=shap_values_3d,
                X_explain_2d=X_explain_2d,
                X_explain_3d=X_explain_tensor.numpy(),
                feature_names=np.array(feature_names),
                country=country,
                model_type=model_name
            )
            print(f"✅ SHAP results saved for {country} → {save_path}")

        except Exception as e:
            print(f"❌ SHAP analysis failed for {country}: {e}")
            import traceback

            traceback.print_exc()
            continue

    print("\n🎉 All countries processed.")