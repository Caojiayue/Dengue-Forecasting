import os
import pandas as pd
from pathlib import Path


def merge_GRU_best_params(base_dir, output_path="params_result/merged_best_params_GRU.csv"):
    base_path = Path(base_dir)
    if not base_path.exists():
        print(f"❌ 目录不存在: {base_path}")
        return

    all_data = []

    # 按文件夹名排序遍历，保证输出顺序稳定
    for country_folder in sorted(base_path.iterdir()):
        if not country_folder.is_dir():
            continue

        country_name = country_folder.name
        csv_path = country_folder / "best_params_GRU.csv"

        if csv_path.exists():
            try:
                df = pd.read_csv(csv_path)
                if df.empty:
                    print(f"⚠️ {country_name}: 文件为空，跳过")
                    continue

                # 1. 在首列插入国家名
                df.insert(0, 'Country', country_name)

                # 2. 若需严格按字面添加 'model' 列，取消下方注释即可
                # df.insert(1, 'model', 'GRU')

                all_data.append(df)
                print(f"✅ 已读取: {country_name}")
            except Exception as e:
                print(f"❌ 读取 {country_name} 失败: {e}")
        else:
            print(f"⚠️ {country_name}: 未找到 best_params_GRU.csv")

    if not all_data:
        print("❌ 未收集到任何有效数据，程序退出。")
        return

    # 合并所有国家数据
    merged_df = pd.concat(all_data, ignore_index=True)

    # 保存结果 (utf-8-sig 确保 Excel 打开时中文/符号不乱码)
    merged_df.to_csv(output_path, index=False, encoding='utf-8-sig')

    print(f"\n🎉 合并成功！共 {len(merged_df)} 行数据。")
    print(f"📁 保存路径: {os.path.abspath(output_path)}")
    print(f"📊 最终列名: {list(merged_df.columns)}")


if __name__ == "__main__":
    # ⬇️ 请替换为您的实际路径
    BASE_DIR = "params_result\GRU(params)"
    merge_GRU_best_params(BASE_DIR)