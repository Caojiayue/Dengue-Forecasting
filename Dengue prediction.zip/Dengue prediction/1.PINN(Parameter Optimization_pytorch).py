import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import time
from scipy.integrate import odeint
import os


class MLP(nn.Module):
    def __init__(self, layers, lb, ub):
        super(MLP, self).__init__()
        self.lb = torch.tensor(lb, dtype=torch.float64)
        self.ub = torch.tensor(ub, dtype=torch.float64)
        self.linears = nn.ModuleList()
        for i in range(len(layers) - 1):
            linear = nn.Linear(layers[i], layers[i + 1], dtype=torch.float64)
            nn.init.xavier_normal_(linear.weight, gain=np.sqrt(2.0 / (layers[i] + layers[i + 1])))
            nn.init.zeros_(linear.bias)
            self.linears.append(linear)

    def forward(self, x):
        H = 2.0 * (x - self.lb) / (self.ub - self.lb) - 1.0
        for i in range(len(self.linears) - 1):
            H = torch.tanh(self.linears[i](H))
        return self.linears[-1](H)


class PhysicsInformedNN(nn.Module):
    def __init__(self, t_train, T_train, Ih_new_train, Ih_sum_train, eta, Nh, U0, lb, ub,
                 layers, layers_Iv, sf, c_a, T_a0, T_a1, c_b, T_b0, T_b1):
        super(PhysicsInformedNN, self).__init__()
        self.eta = eta
        self.sf = sf
        self.Nh_train = torch.tensor(Nh, dtype=torch.float64)
        self.t_train = torch.tensor(t_train, dtype=torch.float64)
        self.T_train = torch.tensor(T_train, dtype=torch.float64)
        self.Ih_new_train = torch.tensor(Ih_new_train, dtype=torch.float64)
        self.Ih_sum_train = torch.tensor(Ih_sum_train, dtype=torch.float64)
        self.Sh0 = torch.tensor(U0[0], dtype=torch.float64)
        self.Ih0 = torch.tensor(U0[1], dtype=torch.float64)
        self.Rh0 = torch.tensor(U0[2], dtype=torch.float64)
        self.lb = torch.tensor(lb, dtype=torch.float64)
        self.ub = torch.tensor(ub, dtype=torch.float64)
        self.c_a = torch.tensor(c_a, dtype=torch.float64)
        self.T_a0 = torch.tensor(T_a0, dtype=torch.float64)
        self.T_a1 = torch.tensor(T_a1, dtype=torch.float64)
        self.c_b = torch.tensor(c_b, dtype=torch.float64)
        self.T_b0 = torch.tensor(T_b0, dtype=torch.float64)
        self.T_b1 = torch.tensor(T_b1, dtype=torch.float64)

        self.net = MLP(layers, self.lb, self.ub)
        self.net_Iv_model = MLP(layers_Iv, self.lb, self.ub)

        self.total_records = []
        self.total_records_LBFGS = []

        self.optimizer_Adam = torch.optim.Adam(self.parameters(), lr=1e-3)
        self.optimizer_LBFGS = torch.optim.LBFGS(self.parameters(), lr=1.0,
                                                 max_iter=50000, max_eval=50000,
                                                 history_size=50, line_search_fn='strong_wolfe')

    def net_u(self, t, Nh):
        ShIhRh = self.net(t)
        Ih = torch.nn.functional.softplus(ShIhRh[:, 0:1])
        Rh = torch.nn.functional.softplus(ShIhRh[:, 1:2])
        Ih_sum = torch.nn.functional.softplus(ShIhRh[:, 2:3])
        Sh = Nh - Ih - Rh
        return Sh, Ih, Rh, Ih_sum

    def net_Iv(self, t):
        Iv = self.net_Iv_model(t)
        return torch.sigmoid(Iv)

    def net_betavh(self, T):
        a = self.c_a * T * (T - self.T_a0) * torch.sqrt(torch.clamp(self.T_a1 - T, min=0.0)) * 30
        b = self.c_b * T * (T - self.T_b0) * torch.sqrt(torch.clamp(self.T_b1 - T, min=0.0))
        a = torch.clamp(a, min=0.0)
        b = torch.clamp(b, min=0.0)
        return a * b

    def net_f(self, t, T, Nh):
        t_req = t.clone().requires_grad_(True)
        betavh = self.net_betavh(T)
        Iv = self.net_Iv(t_req)
        Sh, Ih, Rh, Ih_sum = self.net_u(t_req, Nh)

        Sh_t = torch.autograd.grad(Sh, t_req, grad_outputs=torch.ones_like(Sh), create_graph=True)[0]
        Ih_t = torch.autograd.grad(Ih, t_req, grad_outputs=torch.ones_like(Ih), create_graph=True)[0]
        Rh_t = torch.autograd.grad(Rh, t_req, grad_outputs=torch.ones_like(Rh), create_graph=True)[0]
        Ih_sum_t = torch.autograd.grad(Ih_sum, t_req, grad_outputs=torch.ones_like(Ih_sum), create_graph=True)[0]

        f_Sh = Sh_t + betavh * Iv * Sh / Nh
        f_Ih = Ih_t - betavh * Iv * Sh / Nh + self.eta * Ih
        f_Rh = Rh_t - self.eta * Ih
        f_Ih_sum = Ih_sum_t - (betavh * Iv * Sh / Nh)
        return f_Sh, f_Ih, f_Rh, f_Ih_sum

    def compute_loss(self):
        t = self.t_train
        T = self.T_train
        Nh = self.Nh_train
        Ih_sum = self.Ih_sum_train
        Sh0 = self.Sh0
        Ih0 = self.Ih0
        Rh0 = self.Rh0

        Sh_pred, Ih_pred, Rh_pred, Ih_sum_pred = self.net_u(t, Nh)
        Sh0_pred = Sh_pred[0:1, :]
        Ih0_pred = Ih_pred[0:1, :]
        Rh0_pred = Rh_pred[0:1, :]

        f_Sh, f_Ih, f_Rh, f_Ih_sum = self.net_f(t, T, Nh)

        lossU0 = torch.mean((Sh0 - Sh0_pred) ** 2) + torch.mean((Ih0 - Ih0_pred) ** 2) + torch.mean(
            (Rh0 - Rh0_pred) ** 2)
        lossU = torch.mean((Ih_sum - Ih_sum_pred) ** 2)
        lossF = torch.mean(f_Sh ** 2) + torch.mean(f_Ih ** 2) + torch.mean(f_Rh ** 2) + torch.mean(f_Ih_sum ** 2)

        loss = 100 * lossU0 + 100 * lossU + 100 * lossF
        return loss, lossU0, lossU, lossF

    def train_model(self, nIter):
        start_time = time.time()
        LBFGS_flag = True

        for it in range(nIter + 1):
            def closure():
                self.optimizer_Adam.zero_grad()
                loss, lossU0, lossU, lossF = self.compute_loss()
                loss.backward()
                return loss

            self.optimizer_Adam.step(closure)

            if it % 500 == 0:
                elapsed = time.time() - start_time
                loss, lossU0, lossU, lossF = self.compute_loss()
                self.total_records.append(np.array([it, loss.item(), lossU0.item(), lossU.item(), lossF.item()]))
                print(
                    f'It: {it}, Loss: {loss.item():.3e}, LossU0: {lossU0.item():.3e}, LossU: {lossU.item():.3e}, LossF: {lossF.item():.3e}, Time: {elapsed:.2f}')
                start_time = time.time()

        if LBFGS_flag:
            self.eval()

            def closure_lbfgs():
                self.optimizer_LBFGS.zero_grad()
                loss, lossU0, lossU, lossF = self.compute_loss()
                loss.backward()
                self.total_records_LBFGS.append(np.array([loss.item(), lossU0.item(), lossU.item(), lossF.item()]))
                return loss

            self.optimizer_LBFGS.step(closure_lbfgs)
            self.train()

    def predict_data(self, t_star, Nh_star):
        self.eval()
        with torch.no_grad():
            t_tensor = torch.tensor(t_star, dtype=torch.float64)
            Nh_tensor = torch.tensor(Nh_star, dtype=torch.float64)
            Sh, Ih, Rh, Ih_sum = self.net_u(t_tensor, Nh_tensor)
            Ih_sum_np = Ih_sum.numpy()
            Ih_new_np = Ih_sum_np[1:, :] - Ih_sum_np[0:-1, :]
            return Sh.numpy(), Ih.numpy(), Rh.numpy(), Ih_new_np, Ih_sum_np

    def predict_par(self, t_star):
        self.eval()
        with torch.no_grad():
            t_tensor = torch.tensor(t_star, dtype=torch.float64)
            Iv = self.net_Iv(t_tensor)
            return Iv.numpy()

    def predict_par2(self, T_star):
        self.eval()
        with torch.no_grad():
            T_tensor = torch.tensor(T_star, dtype=torch.float64)
            betavh = self.net_betavh(T_tensor)
            return betavh.numpy()


if __name__ == "__main__":
    TARGET_COUNTRY = 'Barbados'

    data_frame = pd.read_csv('data.csv')
    comb_data = pd.read_csv('comb_data.csv')
    country_data = data_frame[data_frame['country'] == TARGET_COUNTRY].copy()
    country_comb = comb_data[comb_data['country'] == TARGET_COUNTRY].copy()

    c_a = float(country_comb['c_a'].iloc[0])
    T_a0 = float(country_comb['T_a0'].iloc[0])
    T_a1 = float(country_comb['T_a1'].iloc[0])
    c_b = float(country_comb['c_b'].iloc[0])
    T_b0 = float(country_comb['T_b0'].iloc[0])
    T_b1 = float(country_comb['T_b1'].iloc[0])

    Ih_new_raw = country_data['actual_cases'].values.reshape(-1, 1).astype(np.float64)
    Ih_sum_raw = country_data['actual_cumulative'].values.reshape(-1, 1).astype(np.float64)
    sf_min = np.min(Ih_sum_raw)
    sf_max = np.max(Ih_sum_raw)
    sf = sf_max - sf_min

    Ih_new_star = Ih_new_raw / sf
    Ih_sum_star = Ih_sum_raw / sf
    N_star = country_data['total_N'].values.reshape(-1, 1).astype(np.float64) / sf
    T_star = country_data['temperature'].values.reshape(-1, 1).astype(np.float64)
    t_star = np.arange(len(Ih_sum_star), dtype=np.float64).reshape(-1, 1)

    p = float(country_data['total_N'].iloc[0]) - sf_min
    X0 = np.array([p, sf_min, 0, sf_min], dtype=np.float64) / sf
    U0 = [np.array([[p]]) / sf, Ih_sum_star[0:1, :], np.array([[0.0]]) / sf]
    lb, ub = t_star.min(0), t_star.max(0)

    eta = 6
    hidden_layer_depths = [2, 3, 4, 5]
    neuron_widths = [16, 32, 48, 64]

    search_results = []

    for depth in hidden_layer_depths:
        for width in neuron_widths:
            print(f"\n[Searching] Hidden layers: {depth}, Neurons: {width}")
            torch.manual_seed(42)
            np.random.seed(42)

            layers = [1] + [width] * depth + [3]
            layers_Iv = [1] + [width] * depth + [1]

            model = PhysicsInformedNN(t_star, T_star, Ih_new_star, Ih_sum_star,
                                      eta, N_star, U0, lb, ub, layers, layers_Iv, sf,
                                      c_a, T_a0, T_a1, c_b, T_b0, T_b1)
            model.train_model(20000)

            Sh, Ih, Rh, Ih_new_pred, Ih_sum_pred = model.predict_data(t_star, N_star)
            mse_Ih_sum = np.mean((Ih_sum_pred - Ih_sum_star) ** 2)
            mse_Ih_new = np.mean((Ih_new_pred - Ih_new_star[1:]) ** 2)

            search_results.append({'depth': depth, 'width': width, 'mse_Ih_sum': mse_Ih_sum,
                                   'mse_Ih_new': mse_Ih_new, 'total_mse': mse_Ih_sum + mse_Ih_new})

    results_df = pd.DataFrame(search_results)
    best_idx = results_df['total_mse'].idxmin()
    best_params = results_df.iloc[best_idx]
    best_depth, best_width = int(best_params['depth']), int(best_params['width'])
    print(f"\n[Best] Optimal combination: depth={best_depth}, width={best_width}")

    print("\n[Final Training] Training with best parameters and saving all results...")
    torch.manual_seed(42)
    np.random.seed(42)

    layers = [1] + [best_width] * best_depth + [3]
    layers_Iv = [1] + [best_width] * best_depth + [1]

    model = PhysicsInformedNN(t_star, T_star, Ih_new_star, Ih_sum_star, eta, N_star, U0, lb, ub,
                              layers, layers_Iv, sf, c_a, T_a0, T_a1, c_b, T_b0, T_b1)
    model.train_model(20000)

    Sh, Ih, Rh, Ih_new, Ih_sum = model.predict_data(t_star, N_star)
    Iv = model.predict_par(t_star)
    betavh = model.predict_par2(T_star)

    current_directory = os.getcwd()
    save_results_to = os.path.join(current_directory, f'Model_Train/Model_Train({TARGET_COUNTRY})/Train-Results-')
    save_models_to = os.path.join(current_directory, f'Model_Train/Model_Train({TARGET_COUNTRY})/Train-model-')
    os.makedirs(save_results_to, exist_ok=True)
    os.makedirs(save_models_to, exist_ok=True)

    torch.save(model.state_dict(), os.path.join(save_models_to, "model.pth"))

    Sh1, Ih1, Rh1 = Sh * sf, Ih * sf, Rh * sf
    Ih_new1, Ih_sum1 = Ih_new * sf, Ih_sum * sf
    Iv1 = Iv * sf
    results_df.to_csv(os.path.join(save_results_to, 'hyperparameter_mse_results.csv'), index=False)
    np.savetxt(os.path.join(save_results_to, 'Sh.txt'), Sh1.reshape(-1, 1))
    np.savetxt(os.path.join(save_results_to, 'Ih.txt'), Ih1.reshape(-1, 1))
    np.savetxt(os.path.join(save_results_to, 'Rh.txt'), Rh1.reshape(-1, 1))
    np.savetxt(os.path.join(save_results_to, 'Ih_new.txt'), Ih_new1.reshape(-1, 1))
    np.savetxt(os.path.join(save_results_to, 'Ih_sum.txt'), Ih_sum1.reshape(-1, 1))
    np.savetxt(os.path.join(save_results_to, 'Iv.txt'), Iv1.reshape(-1, 1))
    np.savetxt(os.path.join(save_results_to, 'betavh.txt'), betavh.reshape(-1, 1))

    total_records = model.total_records
    total_records_LBFGS = model.total_records_LBFGS

    N_Iter = len(total_records)
    iteration = np.asarray(total_records)[:, 0]
    loss_his = np.asarray(total_records)[:, 1]
    loss_his_u0 = np.asarray(total_records)[:, 2]
    loss_his_u = np.asarray(total_records)[:, 3]
    loss_his_f = np.asarray(total_records)[:, 4]

    np.savetxt(os.path.join(save_results_to, 'iteration.txt'), iteration.reshape(-1, 1))
    np.savetxt(os.path.join(save_results_to, 'loss_his.txt'), loss_his.reshape(-1, 1))
    np.savetxt(os.path.join(save_results_to, 'loss_his_u0.txt'), loss_his_u0.reshape(-1, 1))
    np.savetxt(os.path.join(save_results_to, 'loss_his_u.txt'), loss_his_u.reshape(-1, 1))
    np.savetxt(os.path.join(save_results_to, 'loss_his_f.txt'), loss_his_f.reshape(-1, 1))

    if total_records_LBFGS:
        N_Iter_LBFGS = len(total_records_LBFGS)
        iteration_LBFGS = np.arange(N_Iter_LBFGS) + N_Iter * 100
        loss_his_LBFGS = np.asarray(total_records_LBFGS)[:, 0]
        loss_his_u0_LBFGS = np.asarray(total_records_LBFGS)[:, 1]
        loss_his_u_LBFGS = np.asarray(total_records_LBFGS)[:, 2]
        loss_his_f_LBFGS = np.asarray(total_records_LBFGS)[:, 3]

        np.savetxt(os.path.join(save_results_to, 'iteration_LBFGS.txt'), iteration_LBFGS.reshape(-1, 1))
        np.savetxt(os.path.join(save_results_to, 'loss_his_LBFGS.txt'), loss_his_LBFGS.reshape(-1, 1))
        np.savetxt(os.path.join(save_results_to, 'loss_his_u0_LBFGS.txt'), loss_his_u0_LBFGS.reshape(-1, 1))
        np.savetxt(os.path.join(save_results_to, 'loss_his_u_LBFGS.txt'), loss_his_u_LBFGS.reshape(-1, 1))
        np.savetxt(os.path.join(save_results_to, 'loss_his_f_LBFGS.txt'), loss_his_f_LBFGS.reshape(-1, 1))

    t_star1 = t_star.flatten()


    def Par_fun(t, model):
        t_arr = np.array(t).reshape([1, 1])
        Iv = model.predict_par(t_arr)
        return Iv


    def ODEs_mean(X, t, t_star1, T_star, model, Nh, eta):
        t_idx = np.argmin(np.abs(t_star1 - t))
        T = np.array(T_star[t_idx]).reshape(1, 1)
        betavh_val = model.predict_par2(T).flatten()[0]
        Iv = Par_fun(t, model).flatten()[0]
        Nh1 = Nh[t_idx, 0]
        Sh, Ih, Rh, Isum = X
        dShdt = -betavh_val * Iv * Sh / Nh1
        dIhdt = betavh_val * Iv * Sh / Nh1 - eta * Ih
        dRhdt = eta * Ih
        dsumdt = betavh_val * Iv * Sh / Nh1
        return [float(dShdt), float(dIhdt), float(dRhdt), float(dsumdt)]


    args = (t_star1, T_star, model, N_star, eta)
    Sol = odeint(ODEs_mean, X0, t_star1, args=args)
    Sh_ode, Ih_ode, Rh_ode, ISUM = Sol[:, 0], Sol[:, 1], Sol[:, 2], Sol[:, 3]
    INEW = np.diff(ISUM)

    np.savetxt(os.path.join(save_results_to, 'Sh_ode.txt'), (Sh_ode * sf).reshape(-1, 1))
    np.savetxt(os.path.join(save_results_to, 'Ih_ode.txt'), (Ih_ode * sf).reshape(-1, 1))
    np.savetxt(os.path.join(save_results_to, 'Rh_ode.txt'), (Rh_ode * sf).reshape(-1, 1))
    np.savetxt(os.path.join(save_results_to, 'Inew_ode.txt'), (INEW * sf).reshape(-1, 1))
    np.savetxt(os.path.join(save_results_to, 'Isum_ode.txt'), (ISUM * sf).reshape(-1, 1))

    print("\n[Success] All best model results, loss curves, and ODE validation data have been saved!")