import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
import os
import traceback

class GRUModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size):
        super(GRUModel, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.GRU = nn.GRU(
            input_size=input_size, hidden_size=hidden_size,
            num_layers=num_layers, batch_first=True
        )
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out, _ = self.GRU(x)
        return self.fc(out[:, -1, :])


def create_sequences(X, y, seq_len):
    X_seq, y_seq = [], []
    for i in range(seq_len, len(X)):
        X_seq.append(X[i - seq_len: i])
        y_seq.append(y[i])
    return np.array(X_seq), np.array(y_seq)


def load_and_preprocess_data_for_country(data_df, country, base_iv_dir):
    country_data = data_df[data_df['country'] == country].copy()
    if country_data.empty:
        raise ValueError(f"No data found for country: {country}")

    iv_file = os.path.join(base_iv_dir, f"Model_Train({country})", "Train-Results-", "Iv.txt")
    if not os.path.exists(iv_file):
        iv_file = os.path.join(base_iv_dir, country, "Iv.txt")
        if not os.path.exists(iv_file):
            raise FileNotFoundError(f"Iv.txt not found for {country}")

    Iv1 = pd.read_csv(iv_file, header=None)
    Iv = Iv1.values.astype(np.float32).flatten()

    Ih_new = country_data['actual_cases'].values.astype(np.float32)
    T = country_data['temperature'].values.astype(np.float32)
    R = country_data['precipitation'].values.astype(np.float32)

    if len(T) != len(Iv):
        raise ValueError(f"Length mismatch for {country}: T={len(T)}, Iv={len(Iv)}")

    scaler_X = MinMaxScaler()
    scaler_y = MinMaxScaler()
    X = np.column_stack([T, R, Iv])
    X_scaled = scaler_X.fit_transform(X)
    y_scaled = scaler_y.fit_transform(Ih_new.reshape(-1, 1))

    return X_scaled, y_scaled, scaler_X, scaler_y


def run_iv_uncertainty_analysis():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"🔧 Using device: {device}")

    RESULTS_DIR = "Country_Results"
    DATA_CSV = "data.csv"
    IV_DIR = "Model_Train"


    data_df = pd.read_csv(DATA_CSV)
    #countries = ['Barbados','Costa Rica','El Salvador','Honduras','Mexico','Paraguay','Peru']
    countries = ['Peru']

    COLOR_10 = '#ADD8E6'
    COLOR_20 = '#D8BFD8'

    for country in countries:
        country_dir = os.path.join(RESULTS_DIR, country)
        model_path = os.path.join(country_dir, "GRU_model.pth")

        if not os.path.exists(model_path):
            print(f"⚠️ 跳过 {country}：缺少模型文件")
            continue

        try:
            # 1. 加载 Checkpoint 并严格校验 fixed_params
            checkpoint = torch.load(model_path, map_location=device, weights_only=False)

            if 'fixed_params' not in checkpoint:
                raise KeyError(f"❌ {country} 的 checkpoint 中缺少 'fixed_params' 键，无法继续加载。")

            fp = checkpoint['fixed_params']
            required_keys = ['seq_len', 'hidden_size', 'num_layers']
            for k in required_keys:
                if k not in fp:
                    raise KeyError(f"❌ {country} 的 'fixed_params' 中缺少关键参数: {k}")

            seq_len = int(fp['seq_len'])
            hidden_size = int(fp['hidden_size'])
            num_layers = int(fp['num_layers'])

            # 提取 scaler (若训练时保存了则直接取，否则报错)
            scaler_y = checkpoint.get('scaler_y')
            if scaler_y is None:
                raise KeyError(f"❌ {country} 的 checkpoint 中缺少 'scaler_y'，无法反归一化。")

            # 2. 重建模型并加载权重
            model = GRUModel(input_size=3, hidden_size=hidden_size, num_layers=num_layers, output_size=1).to(device)
            model.load_state_dict(checkpoint['model_state_dict'])
            model.eval()

            # 3. 加载并划分数据
            X_scaled, y_scaled, _, _ = load_and_preprocess_data_for_country(data_df, country, IV_DIR)
            X_seq, y_seq = create_sequences(X_scaled, y_scaled, seq_len)

            if len(X_seq) <= 24:
                print(f"⚠️ {country} 序列数据不足，跳过")
                continue

            split_idx = len(X_seq) - 24
            X_test, y_test = X_seq[split_idx:], y_seq[split_idx:]
            y_test_actual = scaler_y.inverse_transform(y_test).flatten()
            time_indices = np.arange(len(y_test_actual))

            # 4. 施加不确定性并推理 (±10%, ±20%)
            predictions = {}
            deltas = [0.1, -0.1, 0.2, -0.2]
            labels = ['Iv_+10%', 'Iv_-10%', 'Iv_+20%', 'Iv_-20%']

            for delta, label in zip(deltas, labels):
                X_pert = X_test.copy()
                X_pert[:, :, 2] *= (1 + delta)  # 扰动归一化后的 Iv 列(索引2)

                with torch.no_grad():
                    y_pred_scaled = model(torch.tensor(X_pert, dtype=torch.float32).to(device)).cpu().numpy()
                predictions[label] = scaler_y.inverse_transform(y_pred_scaled).flatten()

                # 保存单份结果
                pd.DataFrame({
                    'Time_Step': time_indices,
                    'Actual': y_test_actual,
                    'Predicted': predictions[label]
                }).to_csv(os.path.join(country_dir, f'result_{label}.csv'), index=False, encoding='utf-8-sig')

            # 保存四份合并结果
            df_combined = pd.DataFrame({'Time_Step': time_indices, 'Actual': y_test_actual})
            for label in labels:
                df_combined[f'Predicted_{label}'] = predictions[label]
            df_combined.to_csv(os.path.join(country_dir, 'iv_uncertainty_combined.csv'), index=False,
                               encoding='utf-8-sig')

            # 5. 绘图：按要求配色（上下界线条同色，阴影同色）
            plt.figure(figsize=(12, 6))
            plt.plot(time_indices, y_test_actual, label='Actual', color='black', linewidth=2.5, zorder=5)

            # ±10% 淡蓝色
            plt.fill_between(time_indices, predictions['Iv_+10%'], predictions['Iv_-10%'],
                             color=COLOR_10, alpha=0.45, zorder=2)
            plt.plot(time_indices, predictions['Iv_+10%'], color=COLOR_10, linewidth=2, zorder=3)
            plt.plot(time_indices, predictions['Iv_-10%'], color=COLOR_10, linewidth=2, zorder=3, label='Iv ±10%')

            # ±20% 淡紫色
            plt.fill_between(time_indices, predictions['Iv_+20%'], predictions['Iv_-20%'],
                             color=COLOR_20, alpha=0.45, zorder=1)
            plt.plot(time_indices, predictions['Iv_+20%'], color=COLOR_20, linewidth=2, zorder=2)
            plt.plot(time_indices, predictions['Iv_-20%'], color=COLOR_20, linewidth=2, zorder=2, label='Iv ±20%')

            plt.title(f'{country} - Iv Uncertainty Analysis (±10% & ±20%)', fontsize=14)
            plt.xlabel('Time Steps (Last 24)', fontsize=12)
            plt.ylabel('Cases', fontsize=12)
            plt.legend(loc='best', fontsize=11)
            plt.grid(True, alpha=0.3)
            plt.tight_layout()

            plt.savefig(os.path.join(country_dir, 'iv_uncertainty_plot.png'), dpi=300)
            plt.close()

            print(f"✅ {country} 处理完成 | 结果与绘图已保存")

        except Exception as e:
            print(f"❌ {country} 处理失败: {e}")
            traceback.print_exc()
            continue

    print("\n🎉 所有国家 Iv 不确定性分析完成！")


if __name__ == "__main__":
    run_iv_uncertainty_analysis()